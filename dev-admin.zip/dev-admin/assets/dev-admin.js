/* global DevAdmin */
(function () {
    "use strict";

    function init() {
        // tabs
        jQuery(".dev-tabs button").on("click", function () {
            var t = jQuery(this).data("tab");
            jQuery(".dev-panel").hide();
            jQuery("#tab-" + t).show();
        });

        // REST form
        jQuery("#rest-form").on("submit", function (e) {
            e.preventDefault();
            jQuery("#rest-response").text("loading...");
            jQuery.post(DevAdmin.ajaxUrl, {
                action: "dev_admin_rest_request",
                nonce: DevAdmin.nonce,
                method: jQuery("#rest-method").val(),
                endpoint: jQuery("#rest-endpoint").val(),
                body: jQuery("#rest-body").val(),
            }).done(function (resp) {
                if (resp && resp.success) {
                    jQuery("#rest-response").text("Status: " + resp.data.status + "\n\n" + resp.data.body);
                } else {
                    jQuery("#rest-response").text("Error: " + JSON.stringify(resp));
                }
            }).fail(function (xhr) {
                jQuery("#rest-response").text("Request failed: " + xhr.statusText);
            });
        });

        // CodeMirror editor
        var editor = null;
        var textarea = document.getElementById("code-editor");

        function initEditor() {
            if (editor) {
                return;
            }
            if (typeof CodeMirror === "undefined") {
                console.error("CodeMirror not loaded");
                return;
            }
            editor = CodeMirror.fromTextArea(textarea, {
                lineNumbers: true,
                mode: "application/x-httpd-php",
                indentUnit: 4,
                indentWithTabs: true,
                lineWrapping: true,
            });
        }

        // Delay init so CodeMirror script can load
        if (typeof CodeMirror === "undefined") {
            // try again after short delay
            setTimeout(function () {
                initEditor();
            }, 500);
        } else {
            initEditor();
        }

        jQuery("#btn-load-file").on("click", function () {
            var path = jQuery("#file-path").val().trim();
            if (!path) {
                alert("enter path");
                return;
            }
            jQuery.post(DevAdmin.ajaxUrl, {
                action: "dev_admin_read_file",
                nonce: DevAdmin.nonce,
                path: path,
            }).done(function (r) {
                if (r && r.success) {
                    if (editor) {
                        editor.setValue(r.data.content);
                    } else {
                        jQuery("#code-editor").text(r.data.content);
                    }
                    jQuery("#editor-status").text("Loaded " + path);
                } else {
                    alert("Error: " + (r.data || JSON.stringify(r)));
                }
            }).fail(function (xhr) {
                alert("Error loading file: " + xhr.statusText);
            });
        });

        jQuery("#btn-save-file").on("click", function () {
            var path = jQuery("#file-path").val().trim();
            if (!path) {
                alert("enter path");
                return;
            }
            if (!confirm("Save changes to " + path + "?")) {
                return;
            }
            var content = editor ? editor.getValue() : jQuery("#code-editor").val();
            jQuery.post(DevAdmin.ajaxUrl, {
                action: "dev_admin_save_file",
                nonce: DevAdmin.nonce,
                path: path,
                content: content,
            }).done(function (r) {
                if (r && r.success) {
                    jQuery("#editor-status").text("Saved.");
                } else {
                    alert("Error: " + (r.data || JSON.stringify(r)));
                }
            }).fail(function (xhr) {
                alert("Save failed: " + xhr.statusText);
            });
        });

        // Logs
        jQuery("#btn-tail-logs").on("click", function () {
            jQuery("#log-output").text("Loading...");
            jQuery.post(DevAdmin.ajaxUrl, {
                action: "dev_admin_read_file",
                nonce: DevAdmin.nonce,
                path: "wp-content/debug.log",
            }).done(function (r) {
                if (r && r.success) {
                    jQuery("#log-output").text(r.data.content);
                } else {
                    jQuery("#log-output").text("No logs found or not readable.");
                }
            }).fail(function () {
                jQuery("#log-output").text("Failed to load logs.");
            });
        });

        jQuery("#btn-clear-logs").on("click", function () {
            if (!confirm("Truncate debug.log? This cannot be undone.")) {
                return;
            }
            // Truncate by saving empty string (reuse save file endpoint)
            jQuery.post(DevAdmin.ajaxUrl, {
                action: "dev_admin_save_file",
                nonce: DevAdmin.nonce,
                path: "wp-content/debug.log",
                content: "",
            }).done(function (r) {
                if (r && r.success) {
                    jQuery("#log-output").text("");
                    alert("Logs truncated.");
                } else {
                    alert("Error clearing logs: " + JSON.stringify(r));
                }
            }).fail(function (xhr) {
                alert("Failed to clear logs: " + xhr.statusText);
            });
        });

        // DB runner
        jQuery("#db-form").on("submit", function (e) {
            e.preventDefault();
            var q = jQuery("#db-query").val();
            jQuery("#db-results").text("Running...");
            jQuery.post(DevAdmin.ajaxUrl, {
                action: "dev_admin_db_query",
                nonce: DevAdmin.nonce,
                query: q,
            }).done(function (r) {
                if (r && r.success) {
                    var rows = r.data.rows || [];
                    if (rows.length === 0) {
                        jQuery("#db-results").html("<em>No rows</em>");
                        return;
                    }
                    // build table
                    var table = "<table style='width:100%;border-collapse:collapse;'>";
                    // headers
                    var keys = Object.keys(rows[0]);
                    table += "<thead><tr>";
                    for (var i = 0; i < keys.length; i++) {
                        table += "<th style='border-bottom:1px solid #ddd;padding:6px;text-align:left;'>" + keys[i] + "</th>";
                    }
                    table += "</tr></thead>";
                    // rows
                    table += "<tbody>";
                    for (var rIndex = 0; rIndex < rows.length; rIndex++) {
                        table += "<tr>";
                        for (var kIndex = 0; kIndex < keys.length; kIndex++) {
                            var key = keys[kIndex];
                            var val = rows[rIndex][key];
                            table += "<td style='border-bottom:1px solid #f0f0f0;padding:6px;'>" + (val === null ? "" : escapeHtml(String(val))) + "</td>";
                        }
                        table += "</tr>";
                    }
                    table += "</tbody></table>";
                    jQuery("#db-results").html(table);
                } else {
                    jQuery("#db-results").text("Error: " + (r.data || JSON.stringify(r)));
                }
            }).fail(function (xhr) {
                jQuery("#db-results").text("Request failed: " + xhr.statusText);
            });
        });

        // Command palette shortcut (Ctrl/Cmd+K)
        jQuery(document).on("keydown", function (e) {
            var key = e.key || e.keyCode;
            var isK = (key === "k" || key === "K" || key === 75);
            if ((e.ctrlKey || e.metaKey) && isK) {
                e.preventDefault();
                var el = jQuery("#dev-search");
                el.focus();
                el.select();
            }
        });
    }

    function escapeHtml(text) {
        return text.replace(/[&<>"'`=\/]/g, function (s) {
            return ({
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;",
                "/": "&#x2F;",
                "`": "&#x60;",
                "=": "&#x3D;"
            })[s];
        });
    }

    // run init when DOM ready
    jQuery(document).ready(function () {
        init();
    });
})();

document.addEventListener("DOMContentLoaded", function () {
    function pluginAction(action, plugin = "") {
        if (action === "delete" && !confirm("Are you sure you want to delete " + plugin + "?")) return;
        fetch(ajaxurl, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "action=dev_plugin_action&sub_action=" + action + "&plugin=" + encodeURIComponent(plugin)
        })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    alert("✅ " + data.data);
                    location.reload();
                } else {
                    alert("❌ " + data.data);
                }
            });
    }

    document.querySelectorAll(".qa-activate").forEach(btn =>
        btn.addEventListener("click", () => pluginAction("activate", btn.dataset.plugin))
    );
    document.querySelectorAll(".qa-deactivate").forEach(btn =>
        btn.addEventListener("click", () => pluginAction("deactivate", btn.dataset.plugin))
    );
    document.querySelectorAll(".qa-delete").forEach(btn =>
        btn.addEventListener("click", () => pluginAction("delete", btn.dataset.plugin))
    );
    document.querySelectorAll(".qa-update").forEach(btn =>
        btn.addEventListener("click", () => pluginAction("update", btn.dataset.plugin))
    );

    let bulkBtn = document.getElementById("qa-bulk-update");
    if (bulkBtn) {
        bulkBtn.addEventListener("click", () => {
            if (confirm("Update ALL plugins? This may take time.")) {
                pluginAction("bulk_update");
            }
        });
    }
});
// Hooks Explorer: client-side search + copy
(function () {
    "use strict";

    function hooksInit() {
        var searchEl = jQuery("#hooks-search");
        var table = jQuery("#hooks-table");
        if (!table.length || !searchEl.length) return;

        // simple filter: search text against hook, callback, file
        searchEl.on("input", function () {
            var q = (jQuery(this).val() || "").toLowerCase().trim();
            table.find("tbody tr").each(function () {
                var rowText = jQuery(this).text().toLowerCase();
                var visible = q === "" || rowText.indexOf(q) !== -1;
                jQuery(this).toggle(visible);
            });
        });

        // copy visible rows (tab-separated)
        jQuery("#hooks-copy").on("click", function () {
            var lines = [];
            table.find("tbody tr:visible").each(function () {
                var cols = jQuery(this).find("td");
                var hook = jQuery(cols[0]).text().trim();
                var priority = jQuery(cols[1]).text().trim();
                var callback = jQuery(cols[2]).text().trim();
                var file = jQuery(cols[3]).text().trim();
                var line = jQuery(cols[4]).text().trim();
                lines.push([hook, priority, callback, file, line].join("\t"));
            });
            if (lines.length === 0) {
                alert("No rows to copy.");
                return;
            }
            var text = lines.join("\n");
            // copy to clipboard
            var ta = document.createElement("textarea");
            ta.value = text;
            document.body.appendChild(ta);
            ta.select();
            try {
                document.execCommand("copy");
                alert("Copied " + lines.length + " rows to clipboard.");
            } catch (e) {
                alert("Copy failed. Please select and copy manually.");
            }
            document.body.removeChild(ta);
        });
    }

    // init when ready
    jQuery(document).ready(function () {
        hooksInit();
    });
})();

// Cron Jobs Manager actions
(function () {
    "use strict";

    jQuery(document).on("click", ".run-cron, .delete-cron", function () {
        var btn = jQuery(this);
        var hook = btn.data("hook");
        var timestamp = btn.data("timestamp");
        var args = btn.data("args") || [];
        var action =
            btn.hasClass("run-cron") ? "dev_admin_run_cron" : "dev_admin_delete_cron";

        btn.prop("disabled", true).text("Working...");

        jQuery.post(
            devAdmin.ajax_url,
            {
                action: action,
                hook: hook,
                timestamp: timestamp,
                args: JSON.stringify(args),
                nonce: devAdmin.nonce,
            },
            function (resp) {
                if (resp.success) {
                    alert(resp.data);
                    if (action === "dev_admin_delete_cron") {
                        btn.closest("tr").fadeOut();
                    }
                } else {
                    alert("Error: " + resp.data);
                }
                btn.prop("disabled", false).text(btn.hasClass("run-cron") ? "Run" : "Delete");
            }
        );
    });
})();
// User Session Tracker: force logout
(function () {
    "use strict";

    jQuery(document).on("click", ".logout-session", function () {
        var btn = jQuery(this);
        var user = btn.data("user");
        var token = btn.data("token");

        btn.prop("disabled", true).text("Logging out...");

        jQuery.post(
            devAdmin.ajax_url,
            {
                action: "dev_admin_logout_session",
                user: user,
                token: token,
                nonce: devAdmin.nonce,
            },
            function (resp) {
                if (resp.success) {
                    alert(resp.data);
                    btn.closest("tr").fadeOut();
                } else {
                    alert("Error: " + resp.data);
                    btn.prop("disabled", false).text("Logout");
                }
            }
        );
    });
})();
// WP Options Inspector
(function () {
    "use strict";

    jQuery(document).on("click", ".save-option", function () {
        var btn = jQuery(this);
        var row = btn.closest("tr");
        var name = btn.data("name");
        var value = row.find(".option-value").val();

        btn.prop("disabled", true).text("Saving...");
        jQuery.post(devAdmin.ajax_url, {
            action: "dev_admin_save_option",
            name: name,
            value: value,
            nonce: devAdmin.nonce
        }, function (resp) {
            alert(resp.data);
            btn.prop("disabled", false).text("Save");
        });
    });

    jQuery("#options-search").on("keyup", function () {
        var term = jQuery(this).val();
        jQuery.post(devAdmin.ajax_url, {
            action: "dev_admin_search_options",
            term: term,
            nonce: devAdmin.nonce
        }, function (resp) {
            if (resp.success) {
                jQuery("#options-body").html(resp.data);
            }
        });
    });

})();
