<?php
/*
Plugin Name: Dev Admin Dashboard
Description: Developer-first admin panel: command palette, REST explorer, code editor, logs, DB runner. Accessible only to users with 'manage_dev_admin' capability.
Version: 0.2
Author: You
*/

if (!defined('ABSPATH')) {
    exit;
}

class DevAdminDashboard
{
    const NONCE_ACTION = 'dev_admin_nonce';

    public function __construct()
    {
        register_activation_hook(__FILE__, [$this, 'on_activate']);
        register_deactivation_hook(__FILE__, [$this, 'on_deactivate']);

        add_action('admin_menu', [$this, 'register_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_dev_admin_rest_request', [$this, 'ajax_rest_request']);
        add_action('wp_ajax_dev_admin_read_file', [$this, 'ajax_read_file']);
        add_action('wp_ajax_dev_admin_save_file', [$this, 'ajax_save_file']);
        add_action('wp_ajax_dev_admin_db_query', [$this, 'ajax_db_query']);
        add_action('wp_ajax_dev_plugin_action', [$this, 'handle_plugin_action']);
        add_action('wp_ajax_dev_admin_run_cron', [$this, 'ajax_run_cron']);
        add_action('wp_ajax_dev_admin_delete_cron', [$this, 'ajax_delete_cron']);
        add_action('wp_ajax_dev_admin_logout_session', [$this, 'ajax_logout_session']);
        add_action('wp_ajax_dev_admin_save_option', [$this, 'ajax_save_option']);
        add_action('wp_ajax_dev_admin_search_options', [$this, 'ajax_search_options']);


    }

    /**
     * Activation: create developer role and grant capability to admins (if desired)
     */
    public function on_activate()
    {
        // Add developer role
        if (null === get_role('developer')) {
            add_role('developer', 'Developer', [
                'read' => true,
                'manage_dev_admin' => true,
            ]);
        } else {
            $role = get_role('developer');
            if ($role && !$role->has_cap('manage_dev_admin')) {
                $role->add_cap('manage_dev_admin');
            }
        }

        // Grant capability to administrators by default (optional)
        $admin = get_role('administrator');
        if ($admin && !$admin->has_cap('manage_dev_admin')) {
            $admin->add_cap('manage_dev_admin');
        }
    }

    /**
     * Deactivation: remove developer role (and remove cap from admins)
     */
    public function on_deactivate()
    {
        // Remove capability from administrators
        $admin = get_role('administrator');
        if ($admin && $admin->has_cap('manage_dev_admin')) {
            $admin->remove_cap('manage_dev_admin');
        }

        // Remove the developer role entirely
        if (get_role('developer')) {
            remove_role('developer');
        }
    }

    /**
     * Add menu visible only to users with manage_dev_admin capability
     */
    public function register_menu()
    {
        if (!current_user_can('manage_dev_admin')) {
            return;
        }

        add_menu_page(
            'Dev Admin',
            'Dev Admin',
            'manage_dev_admin',
            'dev-admin-dashboard',
            [$this, 'render_page'],
            'dashicons-admin-tools',
            2
        );
    }

    public function enqueue_assets($hook)
    {
        if ($hook !== 'toplevel_page_dev-admin-dashboard') {
            return;
        }

        // CodeMirror CSS/JS from CDN (v5)
        wp_enqueue_style('codemirror-css', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.14/codemirror.min.css', [], null);
        wp_enqueue_script('codemirror-js', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.14/codemirror.min.js', [], null, true);
        wp_enqueue_script('codemirror-php', 'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.14/mode/php/php.min.js', ['codemirror-js'], null, true);

        // Our JS and CSS assets
        wp_enqueue_style('dev-admin-style', plugin_dir_url(__FILE__) . 'assets/dev-admin.css', [], filemtime(plugin_dir_path(__FILE__) . 'assets/dev-admin.css'));
        wp_enqueue_script('dev-admin-app', plugin_dir_url(__FILE__) . 'assets/dev-admin.js', ['jquery', 'codemirror-js'], filemtime(plugin_dir_path(__FILE__) . 'assets/dev-admin.js'), true);

        wp_localize_script('dev-admin-app', 'DevAdmin', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce(self::NONCE_ACTION),
            'siteUrl' => get_site_url(),
            'env' => defined('WP_ENV') ? WP_ENV : (defined('WP_DEBUG') && WP_DEBUG ? 'development' : 'production'),
        ]);
    }

    public function render_page()
    {
        if (!current_user_can('manage_dev_admin')) {
            wp_die('Forbidden');
        }
        ?>
        <div id="dev-admin-app" class="dev-admin">
            <header class="dev-header">
                <h1>Dev Admin</h1>
                <div class="env-pill">
                    <?php echo esc_html(defined('WP_ENV') ? WP_ENV : (defined('WP_DEBUG') && WP_DEBUG ? 'development' : 'production')); ?>
                </div>
                <input id="dev-search" placeholder="Press ⌘/Ctrl+K — search commands or files..." />
            </header>

            <nav class="dev-tabs">
                <button data-tab="rest">REST Explorer</button>
                <!-- <button data-tab="editor">Code Editor</button> -->
                <button data-tab="logs">Logs</button>
                <button data-tab="db">DB Runner</button>
                <button data-tab="plugins">Plugins</button>
                <button data-tab="hooks">Hooks Explorer</button>
                <button data-tab="cron">Cron Jobs</button>
                <button data-tab="files">File Monitor</button>
                <button data-tab="sessions">User Sessions</button>
                <button data-tab="options">Options Inspector</button>
                <button data-tab="system-info">System Info</button>

            </nav>

            <main class="dev-panels">
                <section id="tab-rest" class="dev-panel">

                    <h2>REST Explorer</h2>
                    <form id="rest-form">
                        <select id="rest-method">
                            <option>GET</option>
                            <option>POST</option>
                            <option>PUT</option>
                            <option>DELETE</option>
                            <option>PATCH</option>
                        </select>
                        <input id="rest-endpoint" placeholder="/wp/v2/posts" />
                        <textarea id="rest-body" placeholder='{"title":"Hello"}'></textarea>
                        <button type="submit" class="button button-primary">Send</button>
                    </form>
                    <pre id="rest-response" class="mono"></pre>
                </section>

                <section id="tab-editor" class="dev-panel" style="display:none">
                    <h2>Code Editor</h2>
                    <div class="file-actions">
                        <input id="file-path"
                            placeholder="Enter path relative to WP root, e.g. wp-content/themes/yourtheme/functions.php" />
                        <button id="btn-load-file" class="button">Load</button>
                        <button id="btn-save-file" class="button button-primary">Save</button>
                    </div>
                    <textarea id="code-editor" style="height:500px"></textarea>
                    <div id="editor-status"></div>
                </section>

                <section id="tab-logs" class="dev-panel" style="display:none">
                    <h2>Logs</h2>
                    <div class="log-actions">
                        <button id="btn-tail-logs" class="button">Load debug.log</button>
                        <button id="btn-clear-logs" class="button" id="btn-clear-logs">Clear (truncate)</button>
                    </div>
                    <pre id="log-output" class="mono"></pre>
                </section>

                <section id="tab-db" class="dev-panel" style="display:none">
                    <h2>DB Runner (READONLY)</h2>
                    <form id="db-form">
                        <textarea id="db-query"
                            placeholder="SELECT ID, post_title FROM wp_posts WHERE post_status='publish' LIMIT 50;"></textarea>
                        <button type="submit" class="button button-primary">Run (readonly)</button>
                    </form>
                    <div id="db-results"></div>
                </section>
                <section id="tab-plugins" class="dev-panel" style="display:none">
                    <h2>Installed Plugins</h2>
                    <div style="margin-bottom:10px;">
                        <button class="button button-secondary" id="qa-bulk-update">Bulk Update All Plugins</button>
                    </div>

                    <table class="widefat striped" style="max-width:100%;font-size:14px;">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Version</th>
                                <th>Status</th>
                                <th>Author</th>
                                <th>Description</th>
                                <th>Path</th>
                                <th>Actions</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                            if (!function_exists('get_plugins')) {
                                require_once ABSPATH . 'wp-admin/includes/plugin.php';
                            }
                            $all_plugins = get_plugins();
                            foreach ($all_plugins as $path => $plugin) {
                                $is_active = is_plugin_active($path);
                                ?>
                                <tr>
                                    <td><strong><?php echo esc_html($plugin['Name']); ?></strong></td>
                                    <td><?php echo esc_html($plugin['Version']); ?></td>
                                    <td><?php echo $is_active ? '<span style="color:green;">Active</span>' : '<span style="color:red;">Inactive</span>'; ?>
                                    </td>
                                    <td><?php echo wp_kses_post($plugin['Author']); ?></td>
                                    <td><?php echo esc_html($plugin['Description']); ?></td>
                                    <td><code><?php echo esc_html($path); ?></code></td>
                                    <td>
                                        <?php if ($is_active): ?>
                                            <button class="button qa-deactivate"
                                                data-plugin="<?php echo esc_attr($path); ?>">Deactivate</button>
                                        <?php else: ?>
                                            <button class="button button-primary qa-activate"
                                                data-plugin="<?php echo esc_attr($path); ?>">Activate</button>
                                        <?php endif; ?>
                                        <button class="button qa-delete"
                                            data-plugin="<?php echo esc_attr($path); ?>">Delete</button>
                                        <button class="button qa-update" data-plugin="<?php echo esc_attr($path); ?>">Check
                                            Update</button>
                                    </td>

                                </tr>
                                <?php
                            }
                            ?>
                        </tbody>

                    </table>
                </section>

                <?php $this->get_system_info(); ?>
                <?php $this->get_hooks_explorer(); ?>
                <?php $this->get_cron_manager(); ?>
                <?php $this->get_file_monitor(); ?>
                <?php $this->get_user_sessions(); ?>
                <section id="tab-options" class="dev-panel" style="display:none">
                    <h2>WP Options Inspector</h2>
                    <input type="text" id="options-search" placeholder="Search option name..."
                        style="margin-bottom:10px;width:300px;" />

                    <table class="widefat striped" style="margin-top:15px;">
                        <thead>
                            <tr>
                                <th>Option Name</th>
                                <th>Value</th>
                                <th>Autoload</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="options-body">
                            <?php $this->render_options_table(); ?>
                        </tbody>
                    </table>
                </section>

            </main>
        </div>
        <?php
    }

    /**
     * REST explorer: forwards a request to the site URL + endpoint (publicly accessible)
     */
    public function ajax_rest_request()
    {
        check_ajax_referer(self::NONCE_ACTION, 'nonce');
        if (!current_user_can('manage_dev_admin')) {
            wp_send_json_error('forbidden');
        }

        $method = sanitize_text_field($_POST['method'] ?? 'GET');
        $endpoint = wp_unslash($_POST['endpoint'] ?? '/wp/v2/posts');
        $body = wp_unslash($_POST['body'] ?? '');

        // Prevent absolute URLs (only allow relative endpoints)
        $endpoint = ltrim($endpoint, '/');

        $url = rtrim(get_site_url(), '/') . '/' . $endpoint;

        $args = [
            'method' => $method,
            'timeout' => 30,
            'redirection' => 5,
            'httpversion' => '1.1',
            'headers' => ['Content-Type' => 'application/json'],
        ];

        if (!empty($body) && in_array($method, ['POST', 'PUT', 'PATCH'])) {
            $args['body'] = $body;
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            wp_send_json_error($response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);

        wp_send_json_success([
            'status' => $code,
            'body' => $response_body,
        ]);
    }

    /**
     * Read file (path relative to ABSPATH)
     */
    public function ajax_read_file()
    {
        check_ajax_referer(self::NONCE_ACTION, 'nonce');
        if (!current_user_can('manage_dev_admin')) {
            wp_send_json_error('forbidden');
        }

        $path = sanitize_text_field($_POST['path'] ?? '');
        if (empty($path)) {
            wp_send_json_error('empty path');
        }

        $real_root = realpath(ABSPATH);
        $target = realpath(ABSPATH . $path);

        if ($target === false || strpos($target, $real_root) !== 0) {
            wp_send_json_error('invalid path');
        }

        if (!is_readable($target) || is_dir($target)) {
            wp_send_json_error('not readable');
        }

        $content = file_get_contents($target);
        if ($content === false) {
            wp_send_json_error('could not read file');
        }

        wp_send_json_success(['content' => $content]);
    }

    /**
     * Save file (path relative to ABSPATH)
     */
    public function ajax_save_file()
    {
        check_ajax_referer(self::NONCE_ACTION, 'nonce');
        if (!current_user_can('manage_dev_admin')) {
            wp_send_json_error('forbidden');
        }

        $path = sanitize_text_field($_POST['path'] ?? '');
        $content = wp_unslash($_POST['content'] ?? '');

        if (empty($path)) {
            wp_send_json_error('empty path');
        }

        $real_root = realpath(ABSPATH);
        $target = realpath(ABSPATH . $path);

        if ($target === false || strpos($target, $real_root) !== 0) {
            wp_send_json_error('invalid path');
        }

        if (!is_writable($target)) {
            wp_send_json_error('not writable');
        }

        $result = file_put_contents($target, $content);

        if ($result === false) {
            wp_send_json_error('failed to write');
        }

        // Optional: write audit log
        $this->audit_log(sprintf('User %s saved file %s', get_current_user_id(), $path));

        wp_send_json_success(['saved' => true]);
    }

    /**
     * Safe readonly DB runner:
     * - only allows single SELECT queries
     * - blocks semicolons and forbidden keywords
     */
    public function ajax_db_query()
    {
        check_ajax_referer(self::NONCE_ACTION, 'nonce');
        if (!current_user_can('manage_dev_admin')) {
            wp_send_json_error('forbidden');
        }

        global $wpdb;

        $query = wp_unslash($_POST['query'] ?? '');
        $query_trim = trim($query);

        if (empty($query_trim)) {
            wp_send_json_error('empty query');
        }

        // Basic safety checks:
        // - Must start with SELECT (case-insensitive)
        // - Must not contain semicolons
        // - Must not contain forbidden keywords
        if (!preg_match('/^\s*SELECT\b/i', $query_trim)) {
            wp_send_json_error('only SELECT queries allowed');
        }

        if (strpos($query_trim, ';') !== false) {
            wp_send_json_error('semicolons are not allowed');
        }

        $forbidden = ['/\\bINSERT\\b/i', '/\\bUPDATE\\b/i', '/\\bDELETE\\b/i', '/\\bDROP\\b/i', '/\\bALTER\\b/i', '/\\bTRUNCATE\\b/i', '/\\bCREATE\\b/i', '/\\bREPLACE\\b/i', '/\\bGRANT\\b/i', '/\\bREVOKE\\b/i'];
        foreach ($forbidden as $pat) {
            if (preg_match($pat, $query_trim)) {
                wp_send_json_error('forbidden keyword in query');
            }
        }

        // Run query (ARRAY_A)
        $results = $wpdb->get_results($query_trim, ARRAY_A);

        if ($wpdb->last_error) {
            wp_send_json_error('db error: ' . esc_html($wpdb->last_error));
        }

        wp_send_json_success(['rows' => $results]);
    }

    private function audit_log($message)
    {
        if (!defined('WP_DEBUG') || !WP_DEBUG) {
            return; // only write audit when WP_DEBUG true to avoid log noise
        }
        $logfile = WP_CONTENT_DIR . '/dev-admin-audit.log';
        $entry = '[' . date('c') . '] ' . $message . PHP_EOL;
        @file_put_contents($logfile, $entry, FILE_APPEND | LOCK_EX);
    }
    public function get_system_info()
    {
        global $wpdb;

        // PHP version
        $php_version = phpversion();

        // MySQL version
        $mysql_version = $wpdb->db_version();

        // WordPress version
        $wp_version = get_bloginfo('version');

        // Active theme
        $theme = wp_get_theme();
        $theme_name = $theme->get('Name');
        $theme_version = $theme->get('Version');

        // Child theme (if active)
        $child_theme = is_child_theme() ? wp_get_theme()->get('Name') : '';

        // Installed plugins count
        $all_plugins = get_plugins();
        $plugin_count = count($all_plugins);

        ?>
        <section id="tab-system-info" class="dev-panel" style="display:none">
            <h2>System Info</h2>
            <table class="widefat striped" style="max-width:600px">
                <tbody>
                    <tr>
                        <th>PHP Version</th>
                        <td><?php echo esc_html($php_version); ?></td>
                    </tr>
                    <tr>
                        <th>MySQL Version</th>
                        <td><?php echo esc_html($mysql_version); ?></td>
                    </tr>
                    <tr>
                        <th>WordPress Version</th>
                        <td><?php echo esc_html($wp_version); ?></td>
                    </tr>
                    <tr>
                        <th>Active Theme</th>
                        <td><?php echo esc_html($theme_name . ' (' . $theme_version . ')'); ?></td>
                    </tr>
                    <?php if ($child_theme): ?>
                        <tr>
                            <th>Child Theme</th>
                            <td><?php echo esc_html($child_theme); ?></td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <th>Installed Plugins</th>
                        <td><?php echo esc_html($plugin_count); ?></td>
                    </tr>
                </tbody>
            </table>
        </section>
        <?php
    }

    public function handle_plugin_action()
    {
        if (!current_user_can('activate_plugins')) {
            wp_send_json_error('Not allowed');
        }

        if (!function_exists('activate_plugin')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $sub_action = sanitize_text_field($_POST['sub_action'] ?? '');
        $plugin = sanitize_text_field($_POST['plugin'] ?? '');

        switch ($sub_action) {
            case 'activate':
                $result = activate_plugin($plugin);
                if (is_wp_error($result)) {
                    wp_send_json_error($result->get_error_message());
                }
                wp_send_json_success("Activated: $plugin");
                break;

            case 'deactivate':
                deactivate_plugins($plugin);
                wp_send_json_success("Deactivated: $plugin");
                break;

            case 'delete':
                if (!current_user_can('delete_plugins')) {
                    wp_send_json_error('You cannot delete plugins.');
                }
                delete_plugins([$plugin]);
                wp_send_json_success("Deleted: $plugin");
                break;
            case 'update':
                if (!current_user_can('update_plugins')) {
                    wp_send_json_error('You cannot update plugins.');
                }
                require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
                $upgrader = new Plugin_Upgrader();
                $result = $upgrader->upgrade($plugin);
                if (is_wp_error($result)) {
                    wp_send_json_error($result->get_error_message());
                }
                wp_send_json_success("Updated: $plugin");
                break;

            case 'bulk_update':
                if (!current_user_can('update_plugins')) {
                    wp_send_json_error('You cannot update plugins.');
                }
                require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
                $upgrader = new Plugin_Upgrader();
                $results = [];
                foreach (array_keys(get_plugins()) as $p) {
                    $res = $upgrader->upgrade($p);
                    $results[] = is_wp_error($res) ? $p . ': ' . $res->get_error_message() : $p . ': Updated';
                }
                wp_send_json_success(implode("\n", $results));
                break;

        }

        wp_send_json_error('Unknown action.');
    }

    /**
     * Hook & Filter Explorer
     * Renders a searchable table of all registered hooks and their callbacks.
     */
    public function get_hooks_explorer()
    {
        if (!current_user_can('manage_dev_admin')) {
            return;
        }

        global $wp_filter;

        // Normalize WP 4.7+ WP_Hook objects
        $hooks = is_array($wp_filter) ? $wp_filter : [];

        // Collect items in flat array for simpler rendering
        $rows = [];

        foreach ($hooks as $hook_name => $wp_hook) {
            // WP_Hook object has ->callbacks; older WP uses arrays
            $callbacks = [];
            if (is_object($wp_hook) && isset($wp_hook->callbacks) && is_array($wp_hook->callbacks)) {
                $callbacks = $wp_hook->callbacks;
            } elseif (is_array($wp_hook)) {
                $callbacks = $wp_hook;
            }

            foreach ($callbacks as $priority => $priority_callbacks) {
                if (!is_array($priority_callbacks))
                    continue;
                foreach ($priority_callbacks as $id => $cb_entry) {
                    // $cb_entry typically has 'function' key for WP_Hook arrays, but for WP_Hook object it's the callback itself
                    $callback = null;
                    if (is_array($cb_entry) && isset($cb_entry['function'])) {
                        $callback = $cb_entry['function'];
                    } else {
                        $callback = $cb_entry;
                    }

                    // Format callback label and try to resolve file + line
                    $label = '';
                    $file = '';
                    $line = '';

                    try {
                        if (is_string($callback)) {
                            $label = $callback;
                            if (function_exists($callback)) {
                                $rf = new ReflectionFunction($callback);
                                $file = $rf->getFileName();
                                $line = $rf->getStartLine();
                            }
                        } elseif (is_array($callback) && count($callback) === 2) {
                            // [object, method] or [class, method]
                            if (is_object($callback[0])) {
                                $cls = get_class($callback[0]);
                                $label = $cls . '->' . $callback[1];
                                if (method_exists($callback[0], $callback[1])) {
                                    $rm = new ReflectionMethod($callback[0], $callback[1]);
                                    $file = $rm->getFileName();
                                    $line = $rm->getStartLine();
                                }
                            } else { // static style ['ClassName','method']
                                $label = $callback[0] . '::' . $callback[1];
                                if (method_exists($callback[0], $callback[1])) {
                                    $rm = new ReflectionMethod($callback[0], $callback[1]);
                                    $file = $rm->getFileName();
                                    $line = $rm->getStartLine();
                                }
                            }
                        } elseif ($callback instanceof Closure) {
                            $label = 'Closure';
                            $rf = new ReflectionFunction($callback);
                            $file = $rf->getFileName();
                            $line = $rf->getStartLine();
                        } elseif (is_object($callback) && method_exists($callback, '__invoke')) {
                            $cls = get_class($callback);
                            $label = $cls . '::__invoke';
                            $rm = new ReflectionMethod($callback, '__invoke');
                            $file = $rm->getFileName();
                            $line = $rm->getStartLine();
                        } else {
                            // fallback print_r
                            $label = is_scalar($callback) ? (string) $callback : wp_json_encode($callback);
                        }
                    } catch (Throwable $t) {
                        // reflection may fail for internal functions etc.
                        $label = is_scalar($callback) ? (string) $callback : (is_object($callback) ? get_class($callback) : json_encode($callback));
                    }

                    $rows[] = [
                        'hook' => $hook_name,
                        'priority' => (int) $priority,
                        'callback' => $label,
                        'file' => $file ?: '',
                        'line' => $line ?: '',
                    ];
                }
            }
        }

        // Sort rows by hook then priority
        usort($rows, function ($a, $b) {
            if ($a['hook'] === $b['hook']) {
                return $a['priority'] <=> $b['priority'];
            }
            return strcmp($a['hook'], $b['hook']);
        });

        // Render the section
        ?>
        <section id="tab-hooks" class="dev-panel" style="display:none">
            <h2>Hooks & Filters Explorer</h2>

            <div style="display:flex;gap:8px;align-items:center;margin-bottom:8px;">
                <input id="hooks-search" placeholder="Search hooks, callbacks, files..."
                    style="flex:1;padding:6px;border:1px solid #ddd;border-radius:6px;" />
                <button id="hooks-copy" class="button">Copy List</button>
            </div>

            <div style="overflow:auto;max-height:520px;">
                <table id="hooks-table" class="widefat striped" style="width:100%;font-size:13px;">
                    <thead>
                        <tr>
                            <th style="width:22%;">Hook</th>
                            <th style="width:8%;">Priority</th>
                            <th style="width:40%;">Callback</th>
                            <th style="width:22%;">File</th>
                            <th style="width:8%;">Line</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as $r): ?>
                            <tr>
                                <td><?php echo esc_html($r['hook']); ?></td>
                                <td><?php echo esc_html($r['priority']); ?></td>
                                <td><?php echo esc_html($r['callback']); ?></td>
                                <td><code style="font-size:12px;"><?php echo esc_html($r['file']); ?></code></td>
                                <td><?php echo esc_html($r['line']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
        <?php
    }
    /**
     * Cron Jobs Manager
     * Lists scheduled cron jobs and allows Run Now / Delete / Reschedule.
     */
    public function get_cron_manager()
    {
        if (!current_user_can('manage_dev_admin')) {
            return;
        }

        if (!function_exists('_get_cron_array')) {
            echo '<section id="tab-cron" class="dev-panel" style="display:none"><h2>Cron Jobs Manager</h2><p>Cron API not available.</p></section>';
            return;
        }

        $crons = _get_cron_array();
        $schedules = wp_get_schedules();

        ?>
        <section id="tab-cron" class="dev-panel" style="display:none">
            <h2>Cron Jobs Manager</h2>

            <table id="cron-table" class="widefat striped" style="width:100%;font-size:13px;">
                <thead>
                    <tr>
                        <th>Hook</th>
                        <th>Next Run (UTC)</th>
                        <th>Recurrence</th>
                        <th>Args</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($crons)): ?>
                        <?php foreach ($crons as $timestamp => $cronhooks): ?>
                            <?php foreach ($cronhooks as $hook => $events): ?>
                                <?php foreach ($events as $key => $event): ?>
                                    <tr>
                                        <td><?php echo esc_html($hook); ?></td>
                                        <td><?php echo gmdate('Y-m-d H:i:s', $timestamp); ?></td>
                                        <td>
                                            <?php
                                            if (!empty($event['schedule']) && isset($schedules[$event['schedule']])) {
                                                echo esc_html($schedules[$event['schedule']]['display']);
                                            } else {
                                                echo $event['schedule'] ? esc_html($event['schedule']) : 'One-time';
                                            }
                                            ?>
                                        </td>
                                        <td><code><?php echo !empty($event['args']) ? esc_html(json_encode($event['args'])) : '-'; ?></code>
                                        </td>
                                        <td>
                                            <button class="button run-cron" data-hook="<?php echo esc_attr($hook); ?>"
                                                data-timestamp="<?php echo esc_attr($timestamp); ?>"
                                                data-args='<?php echo esc_attr(json_encode($event['args'])); ?>'>Run</button>
                                            <button class="button delete-cron" data-hook="<?php echo esc_attr($hook); ?>"
                                                data-timestamp="<?php echo esc_attr($timestamp); ?>"
                                                data-args='<?php echo esc_attr(json_encode($event['args'])); ?>'>Delete</button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5">No scheduled events found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>
        <?php
    }
    // Run cron event immediately
    public function ajax_run_cron()
    {
        if (!current_user_can('manage_dev_admin') || !check_ajax_referer('dev_admin_nonce', 'nonce', false)) {
            wp_send_json_error('Permission denied');
        }

        $hook = sanitize_text_field($_POST['hook'] ?? '');
        $args = json_decode(stripslashes($_POST['args'] ?? '[]'), true);

        if ($hook) {
            do_action($hook, ...($args ?: []));
            wp_send_json_success("Cron hook '$hook' executed.");
        }
        wp_send_json_error('Invalid hook.');
    }

    // Delete cron event
    public function ajax_delete_cron()
    {
        if (!current_user_can('manage_dev_admin') || !check_ajax_referer('dev_admin_nonce', 'nonce', false)) {
            wp_send_json_error('Permission denied');
        }

        $hook = sanitize_text_field($_POST['hook'] ?? '');
        $timestamp = intval($_POST['timestamp'] ?? 0);
        $args = json_decode(stripslashes($_POST['args'] ?? '[]'), true);

        if ($hook && $timestamp) {
            $cleared = wp_unschedule_event($timestamp, $hook, $args ?: []);
            if ($cleared) {
                wp_send_json_success("Cron event '$hook' deleted.");
            }
            wp_send_json_error("Failed to delete cron event '$hook'.");
        }
        wp_send_json_error('Invalid data.');
    }
    /**
     * File Change Monitor
     * Scans wp-content/ for recent file modifications.
     */
    public function get_file_monitor()
    {
        if (!current_user_can('manage_dev_admin')) {
            return;
        }

        $base = WP_CONTENT_DIR;
        $limit = 30; // number of files to show

        $files = [];
        $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base, FilesystemIterator::SKIP_DOTS));

        foreach ($rii as $file) {
            if ($file->isFile()) {
                $files[] = [
                    'path' => str_replace(ABSPATH, '', $file->getPathname()),
                    'mtime' => $file->getMTime(),
                    'size' => size_format($file->getSize())
                ];
            }
        }

        // Sort by modified time descending
        usort($files, function ($a, $b) {
            return $b['mtime'] <=> $a['mtime'];
        });

        $files = array_slice($files, 0, $limit);
        ?>
        <section id="tab-files" class="dev-panel" style="display:none">
            <h2>File Change Monitor</h2>
            <p>Showing latest <?php echo $limit; ?> modified files in <code>wp-content/</code></p>
            <div style="overflow:auto;max-height:500px;">
                <table id="file-monitor" class="widefat striped" style="width:100%;font-size:13px;">
                    <thead>
                        <tr>
                            <th>File</th>
                            <th>Modified</th>
                            <th>Size</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($files as $f): ?>
                            <tr>
                                <td><code><?php echo esc_html($f['path']); ?></code></td>
                                <td><?php echo esc_html(date('Y-m-d H:i:s', $f['mtime'])); ?></td>
                                <td><?php echo esc_html($f['size']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
        <?php
    }
    /**
     * User Session Tracker
     * Lists currently logged-in users with ability to force logout.
     */
    public function get_user_sessions()
    {
        if (!current_user_can('manage_dev_admin')) {
            return;
        }

        $users = get_users();
        ?>
        <section id="tab-sessions" class="dev-panel" style="display:none">
            <h2>User Session Tracker</h2>
            <table id="sessions-table" class="widefat striped" style="width:100%;font-size:13px;">
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Role</th>
                        <th>IP</th>
                        <th>Last Activity</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <?php
                        $sessions = get_user_meta($user->ID, 'session_tokens', true);
                        if (empty($sessions) || !is_array($sessions))
                            continue;

                        foreach ($sessions as $token => $session):
                            $ip = $session['ip'] ?? 'N/A';
                            $login_time = !empty($session['login']) ? date('Y-m-d H:i:s', $session['login']) : 'N/A';
                            ?>
                            <tr>
                                <td><?php echo esc_html($user->user_login . " (#{$user->ID})"); ?></td>
                                <td><?php echo implode(', ', $user->roles); ?></td>
                                <td><?php echo esc_html($ip); ?></td>
                                <td><?php echo esc_html($login_time); ?></td>
                                <td>
                                    <button class="button logout-session" data-user="<?php echo esc_attr($user->ID); ?>"
                                        data-token="<?php echo esc_attr($token); ?>">Logout</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
        <?php
    }
    public function ajax_logout_session()
    {
        if (!current_user_can('manage_dev_admin') || !check_ajax_referer('dev_admin_nonce', 'nonce', false)) {
            wp_send_json_error('Permission denied');
        }

        $user_id = intval($_POST['user'] ?? 0);
        $token = sanitize_text_field($_POST['token'] ?? '');

        if ($user_id && $token) {
            $manager = WP_Session_Tokens::get_instance($user_id);
            $manager->destroy($token);
            wp_send_json_success("User #$user_id session terminated.");
        }

        wp_send_json_error('Invalid request.');
    }
    public function render_options_table()
    {
        global $wpdb;
        $options = $wpdb->get_results("SELECT option_id, option_name, option_value, autoload FROM {$wpdb->options} ORDER BY option_id DESC LIMIT 50");

        if ($options) {
            foreach ($options as $opt) {
                $value = maybe_unserialize($opt->option_value);
                if (is_array($value) || is_object($value)) {
                    $display = '[complex data]';
                } else {
                    $display = strlen($value) > 50 ? substr($value, 0, 50) . '...' : $value;
                }
                ?>
                <tr data-id="<?php echo esc_attr($opt->option_id); ?>">
                    <td><?php echo esc_html($opt->option_name); ?></td>
                    <td>
                        <textarea class="option-value"
                            style="width:100%;height:60px;"><?php echo esc_textarea($opt->option_value); ?></textarea>
                    </td>
                    <td>
                        <?php echo $opt->autoload === 'yes' ? '<span style="color:green;">Yes</span>' : '<span style="color:red;">No</span>'; ?>
                    </td>
                    <td>
                        <button class="button save-option" data-name="<?php echo esc_attr($opt->option_name); ?>">Save</button>
                    </td>
                </tr>
                <?php
            }
        } else {
            echo '<tr><td colspan="4">No options found.</td></tr>';
        }
    }
    public function ajax_save_option()
    {
        if (!current_user_can('manage_dev_admin') || !check_ajax_referer('dev_admin_nonce', 'nonce', false)) {
            wp_send_json_error('Permission denied');
        }

        global $wpdb;
        $name = sanitize_text_field($_POST['name']);
        $value = wp_unslash($_POST['value']);

        if (update_option($name, $value)) {
            wp_send_json_success("Option '$name' updated.");
        } else {
            wp_send_json_error("Failed to update '$name'.");
        }
    }

    public function ajax_search_options()
    {
        if (!current_user_can('manage_dev_admin') || !check_ajax_referer('dev_admin_nonce', 'nonce', false)) {
            wp_send_json_error('Permission denied');
        }

        global $wpdb;
        $term = sanitize_text_field($_POST['term']);
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT option_id, option_name, option_value, autoload 
         FROM {$wpdb->options} 
         WHERE option_name LIKE %s 
         ORDER BY option_id DESC LIMIT 50",
            '%' . $wpdb->esc_like($term) . '%'
        ));

        ob_start();
        if ($results) {
            foreach ($results as $opt) {
                $value = maybe_unserialize($opt->option_value);
                if (is_array($value) || is_object($value)) {
                    $display = '[complex data]';
                } else {
                    $display = strlen($value) > 50 ? substr($value, 0, 50) . '...' : $value;
                }
                ?>
                <tr data-id="<?php echo esc_attr($opt->option_id); ?>">
                    <td><?php echo esc_html($opt->option_name); ?></td>
                    <td>
                        <textarea class="option-value"
                            style="width:100%;height:60px;"><?php echo esc_textarea($opt->option_value); ?></textarea>
                    </td>
                    <td>
                        <?php echo $opt->autoload === 'yes' ? '<span style="color:green;">Yes</span>' : '<span style="color:red;">No</span>'; ?>
                    </td>
                    <td>
                        <button class="button save-option" data-name="<?php echo esc_attr($opt->option_name); ?>">Save</button>
                    </td>
                </tr>
                <?php
            }
        } else {
            echo '<tr><td colspan="4">No results found.</td></tr>';
        }
        wp_send_json_success(ob_get_clean());
    }

}

new DevAdminDashboard();
