=== SAS HRM – Employee & Attendance Management ===
Contributors: Ikramul Shekh
Tags: HRM, employee, attendance, tasks, profile
Requires at least: 6.0
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Short Description ==
A lightweight WordPress HRM plugin to manage employee profiles, tasks, and attendance with simple dashboards and reports.

== Description ==
SAS HRM is a lightweight, user-friendly WordPress plugin for managing employee profiles, daily tasks, and attendance. Track tasks, log working hours, and maintain employee profiles with department and skills information.

== Features ==
* Employee Profile Management:
  * Upload profile picture
  * Add first name, last name, contact number, department, and skills
  * Monthly summary of attendance and completed tasks
* Daily Task Logger:
  * Add multiple tasks per day
  * Track task status: Done, Continue, Pending
  * Copy today’s tasks to clipboard
* Historical Tasks:
  * View all past tasks grouped by date
  * Clean and readable task summary
* Attendance Summary:
  * View monthly worked hours
  * Includes break times in calculations
* Responsive Design:
  * Mobile-friendly and clean UI
  * Styled task lists and profile summaries
* Security & User Management:
  * Only logged-in users can view/update profiles
  * Profile picture upload handled securely using WordPress functions

== Shortcodes ==
| Shortcode | Description |
|———–|————-|
| `[employee_profile]` | Display and edit logged-in employee profile |
| `[daily_task_logger]` | Log today’s tasks and view task summary |
| `[historical_tasks]` | Show historical tasks grouped by date |

== Installation ==
1. Upload the plugin folder to `/wp-content/plugins/`.
2. Activate the plugin via WordPress admin panel.
3. Use the shortcodes in any page or post to display the respective features.

== Frequently Asked Questions ==

= Does this plugin support multi-user? =
Yes. Each logged-in user manages their own profile, tasks, and attendance.

= Can admins view all employees? =
Currently, the focus is on self-management. An admin dashboard is planned in future versions.

= Does it work on mobile? =
Yes, the plugin is fully responsive.

== Screenshots ==
1. Employee profile view and edit screen
2. Daily task logger with task status
3. Historical task summary grouped by date
4. Attendance summary with working/break hours

== Changelog ==
= 1.0 =
* Initial release with profile, task logging, and historical tasks features

== Upgrade Notice ==
= 1.0 =
First stable release. Upgrade to get employee profiles, task logging, and attendance summaries.

== Upcoming Features ==
* Employee Document Vault (upload ID proofs, certificates, contracts)
* Department-specific announcements
* Task attachments (upload files/screenshots to tasks)

