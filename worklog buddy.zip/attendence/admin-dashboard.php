<?php
if (!defined('ABSPATH'))
    exit;

// Admin menu
add_action('admin_menu', function () {
    add_menu_page('Attendance Logs', 'Attendance Logs', 'manage_options', 'sas-admin', 'sas_admin_page');
    add_submenu_page(
        'sas-admin',              // parent slug
        'Leave Management',       // page title
        'Leave Management',       // menu title
        'manage_options',         // capability
        'sas-leaves',             // menu slug
        'sas_leave_page'          // callback function
    );
    add_submenu_page(
        'sas-admin',              // parent slug
        'Holiday Calendar',       // page title
        'Holiday Calendar',       // menu title
        'manage_options',         // capability
        'sas-holidays',           // menu slug
        'sas_holiday_page'        // callback function
    );
});

// Helper: Calculate worked hours minus break
function sas_format_hours_minutes($start, $end, $break_start = null, $break_end = null)
{
    if (!$start || !$end)
        return '00:00';
    $start_ts = strtotime($start);
    $end_ts = strtotime($end);
    if ($end_ts < $start_ts)
        return '00:00';

    $worked_seconds = $end_ts - $start_ts;

    if ($break_start && $break_end) {
        $break_seconds = strtotime($break_end) - strtotime($break_start);
        if ($break_seconds > 0)
            $worked_seconds -= $break_seconds;
    }

    $hours = floor($worked_seconds / 3600);
    $minutes = floor(($worked_seconds % 3600) / 60);
    return sprintf('%02d:%02d', $hours, $minutes);
}

// Helper: Calculate break hours
function sas_format_break_hours($break_start, $break_end)
{
    if (!$break_start || !$break_end)
        return '00:00';
    $seconds = strtotime($break_end) - strtotime($break_start);
    if ($seconds <= 0)
        return '00:00';
    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    return sprintf('%02d:%02d', $hours, $minutes);
}

// Helper: Calculate extra/deficit hours
function sas_calc_extra_deficit($worked_hm, $required_hours = 8.5)
{
    $worked_hm = $worked_hm ?: '00:00';
    list($h, $m) = explode(':', $worked_hm);
    $h = intval($h);
    $m = intval($m);

    $worked_seconds = ($h * 3600) + ($m * 60);
    $required_seconds = $required_hours * 3600;
    $diff_seconds = $worked_seconds - $required_seconds;

    if ($diff_seconds >= 0) {
        $status = 'Extra';
    } else {
        $status = 'Deficit';
        $diff_seconds = abs($diff_seconds);
    }

    $diff_h = floor($diff_seconds / 3600);
    $diff_m = floor(($diff_seconds % 3600) / 60);
    $diff_hm = sprintf('%02d:%02d', $diff_h, $diff_m);

    return [$status, $diff_hm, $diff_seconds];
}

// Admin page
function sas_admin_page()
{
    global $wpdb;
    $table = $wpdb->prefix . 'attendance_logs';

    // Handle Edit
    if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $log = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d", $id));

        if ($log) {
            if ($_POST && check_admin_referer('sas_edit_log')) {
                $start_time = sanitize_text_field($_POST['start_time']);
                $break_start_time = sanitize_text_field($_POST['break_start_time']);
                $break_end_time = sanitize_text_field($_POST['break_end_time']);
                $end_time = sanitize_text_field($_POST['end_time']);

                $work_hours = sas_format_hours_minutes($start_time, $end_time, $break_start_time, $break_end_time);
                $break_hours = sas_format_break_hours($break_start_time, $break_end_time);

                $wpdb->update(
                    $table,
                    [
                        'start_time' => $start_time,
                        'break_start_time' => $break_start_time,
                        'break_end_time' => $break_end_time,
                        'end_time' => $end_time,
                        'work_hours' => $work_hours,
                        'break_hours' => $break_hours
                    ],
                    ['id' => $id]
                );

                echo '<div class="updated notice"><p>Attendance updated!</p></div>';
                $log = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id=%d", $id));
            }

            ?>
            <div class="wrap">
                <h2>Edit Attendance for User ID <?= esc_html($log->user_id) ?> on <?= esc_html($log->date) ?></h2>
                <form method="post">
                    <?php wp_nonce_field('sas_edit_log'); ?>
                    <table class="form-table">
                        <tr>
                            <th>Start Time</th>
                            <td><input type="time" name="start_time"
                                    value="<?= $log->start_time ? date('H:i', strtotime($log->start_time)) : '' ?>"></td>
                        </tr>
                        <tr>
                            <th>Break Start</th>
                            <td><input type="time" name="break_start_time"
                                    value="<?= $log->break_start_time ? date('H:i', strtotime($log->break_start_time)) : '' ?>">
                            </td>
                        </tr>
                        <tr>
                            <th>Break End</th>
                            <td><input type="time" name="break_end_time"
                                    value="<?= $log->break_end_time ? date('H:i', strtotime($log->break_end_time)) : '' ?>"></td>
                        </tr>
                        <tr>
                            <th>End Time</th>
                            <td><input type="time" name="end_time"
                                    value="<?= $log->end_time ? date('H:i', strtotime($log->end_time)) : '' ?>"></td>
                        </tr>
                    </table>
                    <?php submit_button('Update Attendance'); ?>
                </form>
                <p><a href="<?= admin_url('admin.php?page=sas-admin') ?>" class="button">Back to Attendance Logs</a></p>
            </div>
            <?php
            return;
        }
    }

    // Default: Display Logs
    $logs = $wpdb->get_results("SELECT l.*, u.user_login FROM $table l JOIN {$wpdb->users} u ON l.user_id=u.ID ORDER BY l.date DESC");

    // Monthly cumulative extra/deficit
    $month_start = date('Y-m-01');
    $month_end = date('Y-m-t');

    $user_totals = [];
    foreach ($logs as $l) {
        if (!isset($user_totals[$l->user_id]))
            $user_totals[$l->user_id] = 0;

        $log_date_ts = strtotime($l->date);
        if ($log_date_ts >= strtotime($month_start) && $log_date_ts <= strtotime($month_end)) {
            if ($l->end_time) {
                list($status, $diff_hm, $diff_seconds) = sas_calc_extra_deficit($l->work_hours);
                if ($status === 'Extra')
                    $user_totals[$l->user_id] += $diff_seconds;
                else
                    $user_totals[$l->user_id] -= $diff_seconds;
            }
        }
    }

    echo '<div class="wrap"><h1>Attendance Logs</h1>';

    // Monthly totals table
    echo '<h2>Monthly Totals</h2><table class="widefat"><thead>
    <tr><th>User</th><th>Extra / Deficit Hours This Month</th></tr></thead><tbody>';
    foreach ($user_totals as $user_id => $seconds) {
        $status = $seconds >= 0 ? 'Extra' : 'Deficit';
        $color = $status === 'Extra' ? '#4caf50' : '#f44336';
        $seconds = abs($seconds);
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $hm = sprintf('%02d:%02d', $hours, $minutes);
        $user = get_userdata($user_id);
        $username = $user ? $user->user_login : 'Unknown';
        echo "<tr><td>{$username}</td><td style='color:{$color}; font-weight:bold'>{$hm} ({$status})</td></tr>";
    }
    echo '</tbody></table>';

    // Daily logs table
    echo '<h2>Daily Logs</h2><table class="widefat"><thead>
    <tr>
        <th>User</th>
        <th>Date</th>
        <th>Start</th>
        <th>Break Start</th>
        <th>Break End</th>
        <th>End</th>
        <th>Work Hours</th>
        <th>Break Hours</th>
        <th>Status</th>
        <th>Diff</th>
        <th>Actions</th>
    </tr></thead><tbody>';

    foreach ($logs as $l) {
        if (empty($l->end_time)) {
            $status = 'Pending';
            $diff_hm = '-';
            $color = '#999';
        } else {
            list($status, $diff_hm, $diff_seconds) = sas_calc_extra_deficit($l->work_hours);
            $color = $status === 'Extra' ? '#4caf50' : '#f44336';
        }

        echo "<tr>
            <td>{$l->user_login}</td>
            <td>{$l->date}</td>
            <td>{$l->start_time}</td>
            <td>{$l->break_start_time}</td>
            <td>{$l->break_end_time}</td>
            <td>{$l->end_time}</td>
            <td>{$l->work_hours}</td>
            <td>{$l->break_hours}</td>
            <td style='color:{$color}; font-weight:bold'>{$status}</td>
            <td>{$diff_hm}</td>
            <td><a href='" . admin_url("admin.php?page=sas-admin&action=edit&id={$l->id}") . "' class='button'>Edit</a></td>
        </tr>";
    }

    echo '</tbody></table></div>';
}


//Leave Management 
function sas_leave_page()
{
    global $wpdb;
    $leave_table = $wpdb->prefix . 'attendance_leaves';

    // ✅ Handle Approve/Reject actions
    if (isset($_GET['action'], $_GET['id']) && in_array($_GET['action'], ['approve', 'reject'])) {
        $id = intval($_GET['id']);
        $action = sanitize_text_field($_GET['action']);
        $new_status = $action === 'approve' ? 'approved' : 'rejected';

        $wpdb->update(
            $leave_table,
            ['status' => $new_status],
            ['id' => $id],
            ['%s'],
            ['%d']
        );

        echo '<div class="notice notice-success is-dismissible"><p>Leave request has been <strong>' . ucfirst($new_status) . '</strong>.</p></div>';
    }

    // ✅ Fetch all leave requests
    $leave_results = $wpdb->get_results("SELECT * FROM $leave_table ORDER BY created_at DESC");

    echo '<div class="wrap"><h1>Leave Management</h1>';
    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr>
            <th>ID</th><th>User</th><th>Date</th><th>Type</th>
            <th>Hours</th><th>Reason</th><th>Status</th><th>Action</th>
          </tr></thead><tbody>';

    if ($leave_results) {
        foreach ($leave_results as $row) {
            $user = get_userdata($row->user_id);
            echo '<tr>';
            echo '<td>' . esc_html($row->id) . '</td>';
            echo '<td>' . esc_html($user ? $user->user_login : 'Unknown') . '</td>';
            echo '<td>' . esc_html($row->leave_date) . '</td>';
            echo '<td>' . esc_html(ucfirst(str_replace("_", " ", $row->leave_type))) . '</td>';
            echo '<td>' . esc_html($row->leave_hours) . '</td>';
            echo '<td>' . esc_html($row->reason) . '</td>';
            echo '<td><strong>' . ucfirst($row->status) . '</strong></td>';
            echo '<td>';
            if ($row->status == 'pending') {
                echo '<a href="?page=sas-leaves&action=approve&id=' . $row->id . '" class="button button-primary">Approve</a> ';
                echo '<a href="?page=sas-leaves&action=reject&id=' . $row->id . '" class="button">Reject</a>';
            } else {
                echo '<em>No action</em>';
            }
            echo '</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="8">No leave requests found.</td></tr>';
    }

    echo '</tbody></table></div>';
}
add_action('admin_menu', 'sas_holiday_menu');

function sas_holiday_menu()
{
    add_menu_page(
        'Holiday Calendar',
        'Holidays',
        'manage_options',
        'sas-holidays',
        'sas_holiday_page',
        'dashicons-calendar-alt',
        26
    );
}

function sas_holiday_page()
{
    global $wpdb;
    $table = $wpdb->prefix . 'sas_holidays';

    // Handle manual add
    if (isset($_POST['sas_add_holiday'])) {
        $date = sanitize_text_field($_POST['holiday_date']);
        $name = sanitize_text_field($_POST['holiday_name']);
        $type = sanitize_text_field($_POST['holiday_type']);
        $wpdb->insert($table, [
            'date' => $date,
            'name' => $name,
            'type' => $type
        ]);
        echo '<div class="updated"><p>Holiday added!</p></div>';
    }

    // Handle CSV upload
    if (isset($_POST['sas_import_csv']) && !empty($_FILES['holiday_csv']['tmp_name'])) {
        $file = fopen($_FILES['holiday_csv']['tmp_name'], 'r');
        if ($file) {
            fgetcsv($file); // skip header row
            while (($row = fgetcsv($file)) !== false) {
                $date = sanitize_text_field($row[0]);
                $name = sanitize_text_field($row[1]);
                $type = isset($row[2]) ? sanitize_text_field($row[2]) : 'full';

                $exists = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM $table WHERE date=%s AND name=%s",
                    $date,
                    $name
                ));

                if (!$exists) {
                    $wpdb->insert($table, [
                        'date' => $date,
                        'name' => $name,
                        'type' => $type
                    ]);
                }
            }
            fclose($file);
            echo '<div class="updated"><p>CSV imported successfully!</p></div>';
        }
    }

    // Show UI
    echo '<div class="wrap"><h1>Holiday Calendar</h1>';

    // Manual add form
    echo '<form method="post">
        <input type="date" name="holiday_date" required> 
        <input type="text" name="holiday_name" placeholder="Holiday Name" required> 
        <select name="holiday_type">
            <option value="full">Full Day</option>
            <option value="half">Half Day</option>
        </select> 
        <input type="submit" name="sas_add_holiday" class="button-primary" value="Add Holiday">
    </form><br>';

    // CSV Upload form
    echo '<h2>Import Holidays (CSV)</h2>
        <form method="post" enctype="multipart/form-data">
            <input type="file" name="holiday_csv" accept=".csv" required>
            <input type="submit" name="sas_import_csv" class="button-secondary" value="Upload CSV">
        </form><br>';

    // Show upcoming holidays
    $holidays = $wpdb->get_results("SELECT * FROM $table ORDER BY date ASC");
    echo '<h2>Upcoming Holidays</h2><table class="widefat"><tr><th>Date</th><th>Name</th><th>Type</th></tr>';
    foreach ($holidays as $h) {
        echo "<tr><td>{$h->date}</td><td>{$h->name}</td><td>{$h->type}</td></tr>";
    }
    echo '</table></div>';
}
