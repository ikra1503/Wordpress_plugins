<?php
if (!defined('ABSPATH'))
    exit;

// Shortcode for user dashboard
add_shortcode('attendance_dashboard', 'sas_user_dashboard');
function sas_user_dashboard()
{
    if (!is_user_logged_in())
        return '<p>Please login to view attendance dashboard.</p>';

    $user_id = get_current_user_id();
    $today = date('Y-m-d', current_time('timestamp')); // only date for today
    global $wpdb;
    $table = $wpdb->prefix . 'attendance_logs';

    // Get today's log
    $log = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table WHERE user_id=%d AND date=%s",
        $user_id,
        $today
    ));

    ob_start();
    ?>
    <div class="sas-dashboard">
        <div class="container">
            <div class="row">
                <div class="col-md-9 mt-15">
                    <?php
                    $tomorrow_leave = sas_get_tomorrow_leave($user_id);
                    $leave_notification = '';
                    if ($tomorrow_leave) {
                        $leave_notification = '<div class="sas-leave-notification">
                        Reminder: You have a leave scheduled for tomorrow (' . date('d M Y', strtotime($tomorrow_leave['leave_date'])) . '). Please inform your group.
                    </div>';
                    }
                    ?>
                    <?php
                    if (is_user_logged_in()) {
                        $current_user = wp_get_current_user();
                        $display_name = $current_user->display_name;

                        // Get WordPress local hour (0-23)
                        $hour = intval(date('G', current_time('timestamp')));

                        if ($hour >= 5 && $hour < 12) {
                            $greeting = "Good Morning";
                            $emoji = "🌅";
                        } elseif ($hour >= 12 && $hour < 16) {
                            $greeting = "Good Afternoon";
                            $emoji = "🌤️";
                        } elseif ($hour >= 16 && $hour < 21) {
                            $greeting = "Good Evening";
                            $emoji = "🌇";
                        } else {
                            $greeting = "Good Night";
                            $emoji = "🌙";
                        }

                        echo "<h1>{$greeting}, 👋 " . esc_html($display_name) . " {$emoji}</h1>";
                    }
                    ?>

                    <br>
                    <p id="sas-status" style="font-weight:bold; font-size:16px;">Status: -</p>
                    <br />
                    <a href="<?php echo site_url('/leave'); ?>" class="sas-leaves-btn"> Leaves</a>
                    <a href="<?php echo site_url('/task'); ?>" class="sas-task-btn"> Add your task</a>
                    <div id="sas-local-clock" style="font-size:18px; font-weight:bold; margin-bottom:10px;"></div>
                    <?php echo $leave_notification; ?>

                    <div class="sas-buttons">
                        <button class="sas-btn" data-action="start_day">Start Day</button>
                        <button class="sas-btn" data-action="start_break">Start Break</button>
                        <button class="sas-btn" data-action="end_break">End Break</button>
                        <button class="sas-btn" data-action="end_day">End Day</button>
                    </div>
                </div>
                <div class="col-md-3">
                    <?php include_once(plugin_dir_path(__FILE__) . 'clock.html'); ?>
                </div>
            </div>
        </div>
        <div class="container mt-4">
            <div class="row">
                <div class="col-md-6">
                    <div class="sas-today">
                        <h3>Today's Update</h3>
                        <p>Start Time: <span
                                id="sas-start"><?= $log && $log->start_time ? date('h:i A', strtotime($log->start_time)) : '-' ?></span>
                        </p>
                        <p>Break Start: <span
                                id="sas-break-start"><?= $log && $log->break_start_time ? date('h:i A', strtotime($log->break_start_time)) : '-' ?></span>
                        </p>
                        <p>Break End: <span
                                id="sas-break-end"><?= $log && $log->break_end_time ? date('h:i A', strtotime($log->break_end_time)) : '-' ?></span>
                        </p>
                        <p>End Time: <span
                                id="sas-end"><?= $log && $log->end_time ? date('h:i A', strtotime($log->end_time)) : '-' ?></span>
                        </p>
                        <p>Worked Hours: <span
                                id="sas-work"><?= $log ? format_hours_minutes($log->start_time, $log->end_time, $log->break_start_time, $log->break_end_time) : '00:00' ?></span>
                        </p>
                        <p>Break Hours: <span
                                id="sas-break-hours"><?= $log ? format_break_hours($log->break_start_time, $log->break_end_time) : '00:00' ?></span>
                        </p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div id="sas-weekly-summary-container">
                        <?php sas_weekly_summary(); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-mt-4">
            <div class="row">
                <div id="sas-daily-breakdown-container">
                    <?php sas_daily_breakdown(); ?>
                </div>
            </div>
        </div>
        <div class="sas-monthly">
            <h3>Monthly Attendance</h3>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Start</th>
                        <th>End</th>
                        <th>Work Hours</th>
                        <th>Extra Hours</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    global $wpdb;
                    $table = $wpdb->prefix . "attendance_logs";
                    $leaves_table = $wpdb->prefix . "attendance_leaves";

                    $user_id = get_current_user_id();
                    $month_start = date('Y-m-01', current_time('timestamp'));
                    $month_end = date('Y-m-t', current_time('timestamp'));

                    $logs = $wpdb->get_results($wpdb->prepare(
                        "SELECT * FROM $table WHERE user_id=%d AND date BETWEEN %s AND %s",
                        $user_id,
                        $month_start,
                        $month_end
                    ));

                    $total_worked_seconds = 0;
                    $total_extra_seconds = 0;
                    $total_deficit_seconds = 0;
                    $daily_required_seconds = 8.5 * 3600;
                    $underworked_days = [];
                    $today_date = date('Y-m-d', current_time('timestamp'));

                    foreach ($logs as $l) {
                        $worked_hm = format_hours_minutes($l->start_time, $l->end_time, $l->break_start_time, $l->break_end_time);
                        list($h, $m) = explode(':', $worked_hm);
                        $worked_seconds = ($h * 3600) + ($m * 60);

                        // Extra hours
                        $extra_seconds_today = max($worked_seconds - $daily_required_seconds, 0);
                        $total_extra_seconds += $extra_seconds_today;

                        // Total worked
                        $total_worked_seconds += $worked_seconds;

                        // Convert extra to HH:MM
                        $extra_hm_today = sprintf('%02d:%02d', floor($extra_seconds_today / 3600), floor(($extra_seconds_today % 3600) / 60));


                        echo "<tr>
                    <td>{$l->date}</td>
                    <td>" . ($l->start_time ? date('h:i A', strtotime($l->start_time)) : '-') . "</td>
                    <td>" . ($l->end_time ? date('h:i A', strtotime($l->end_time)) : '-') . "</td>
                    <td>{$worked_hm}</td>
                    <td>{$extra_hm_today}</td>
                  </tr>";

                        // Deficit check (exclude today, weekends, half/full leave)
                        $weekday = date('N', strtotime($l->date));
                        $leave_type = isset($l->leave_type) ? strtolower($l->leave_type) : '';
                        $worked_decimal = $worked_seconds / 3600;

                        if ($worked_decimal < 8.5 && $l->date < $today_date && $weekday < 6 && $leave_type !== 'half' && $leave_type !== 'full') {
                            $deficit_seconds = (8.5 * 3600) - $worked_seconds;
                            $underworked_days[] = [
                                'date' => $l->date,
                                'work_hours' => $worked_seconds,
                                'leave_type' => $leave_type ? ucfirst($leave_type) : 'None',
                                'deficit_seconds' => $deficit_seconds
                            ];
                            $total_deficit_seconds += $deficit_seconds;
                        }
                    }

                    // Convert total worked, extra, deficit to HH:MM
                    $total_worked_hm = sprintf('%02d:%02d', floor($total_worked_seconds / 3600), floor(($total_worked_seconds % 3600) / 60));
                    $total_extra_hm = sprintf('%02d:%02d', floor($total_extra_seconds / 3600), floor(($total_extra_seconds % 3600) / 60));
                    $total_deficit_hm = sprintf('%02d:%02d', floor($total_deficit_seconds / 3600), floor(($total_deficit_seconds % 3600) / 60));

                    // Total required hours for month (Mon-Fri)
                    $required_hours = 0;
                    $current = strtotime($month_start);
                    $end_time = strtotime($month_end);
                    while ($current <= $end_time) {
                        $weekday = date('N', $current);
                        if ($weekday < 6)
                            $required_hours += 8.5;
                        $current = strtotime('+1 day', $current);
                    }
                    $required_seconds = $required_hours * 3600;

                    // Total leave hours
                    $leave_hours_total = $wpdb->get_var($wpdb->prepare(
                        "SELECT SUM(leave_hours) FROM $leaves_table WHERE user_id=%d AND leave_date BETWEEN %s AND %s AND status='approved'",
                        $user_id,
                        $month_start,
                        $month_end
                    ));
                    $leave_hours_total = $leave_hours_total ? $leave_hours_total : 0;
                    $leave_total_hm = sprintf('%02d:%02d', floor($leave_hours_total), round(($leave_hours_total - floor($leave_hours_total)) * 60));

                    // Final balance
                    $final_balance_seconds = $total_extra_seconds - $total_deficit_seconds;
                    $final_balance_hm = sprintf('%02d:%02d', floor(abs($final_balance_seconds) / 3600), floor((abs($final_balance_seconds) % 3600) / 60));
                    $final_status_text = $final_balance_seconds < 0 ? "Final Deficit Balance" : "Final Extra Balance";
                    $final_color = $final_balance_seconds < 0 ? "#f44336" : "#4caf50";

                    // Current month pending / deficit hours
                    $current_month_deficit_seconds = $required_seconds - ($total_worked_seconds + ($leave_hours_total * 3600));
                    if ($current_month_deficit_seconds < 0)
                        $current_month_deficit_seconds = 0;
                    $current_month_deficit_hm = sprintf('%02d:%02d', floor($current_month_deficit_seconds / 3600), floor(($current_month_deficit_seconds % 3600) / 60));

                    // Progress bar
                    $progress = min(round((($total_worked_seconds + ($leave_hours_total * 3600)) / max($required_seconds, 1)) * 100, 1), 100);
                    $bar_color = ($total_worked_seconds + ($leave_hours_total * 3600)) < $required_seconds ? '#f44336' : '#4caf50';
                    ?>
                </tbody>
            </table>

            <div class="summary-of-month">
                <h3>Monthly Summary</h3>
                <ul>
                    <li><span>Current Month Required Hours:</span> <?= $required_hours ?> hours</li>
                    <li><span>Total Worked Hours This Month:</span> <?= $total_worked_hm ?> hours</li>
                    <li><span>Total Extra Hours Accumulated:</span> <?= $total_extra_hm ?> hours</li>
                    <li><span>Total Deficit Hours Accumulated:</span> <?= $total_deficit_hm ?> hours</li>
                    <li class="status" style="color:<?= $final_color ?>;">
                        <span><?= $final_status_text ?>:</span> <?= $final_balance_hm ?> hours
                    </li>
                    <li><span>Total Approved Leave Hours This Month:</span> <?= $leave_total_hm ?> hours</li>
                    <li style="
    background-color: <?= $current_month_deficit_seconds > 0 ? '#f44336' : 'inherit' ?>;
">
                        <span style="color: <?= $current_month_deficit_seconds > 0 ? '#ffffff' : 'inherit' ?>;">
                            Current Month Pending / Deficit Hours:
                        </span>
                        <span style="color: <?= $current_month_deficit_seconds > 0 ? '#ffffff' : 'inherit' ?>;">
                            <?= $current_month_deficit_hm ?> hours
                        </span>
                    </li>

                </ul>
            </div>

            <!-- Progress Bar -->
            <div style="margin-top:10px;">
                <strong>Progress:</strong>
                <div style="background:#eee; width:100%; border-radius:5px; overflow:hidden; height:20px; margin-top:5px;">
                    <div
                        style="width:<?= $progress ?>%; background:<?= $bar_color ?>; height:100%; text-align:center; color:white; line-height:20px;">
                        <?= $progress ?>%
                    </div>
                </div>
            </div>

            <!-- Underworked Days Table -->
            <?php if (!empty($underworked_days)): ?>
                <div class="debug-underworked" style="margin-top:20px;">
                    <h3>⚠️ Days with Less than 8.5 Hours</h3>
                    <table border="1" cellpadding="5" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Worked Hours</th>
                                <!-- <th>Leave Type</th> -->
                                <th>Deficit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($underworked_days as $day):
                                $worked_hm = sprintf('%02d:%02d', floor($day['work_hours'] / 3600), floor(($day['work_hours'] % 3600) / 60));
                                $deficit_hm = sprintf('%02d:%02d', floor($day['deficit_seconds'] / 3600), floor(($day['deficit_seconds'] % 3600) / 60));
                                ?>
                                <tr>
                                    <td><?= $day['date'] ?></td>
                                    <td><?= $worked_hm ?></td>
                                    <td><?= $deficit_hm ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <p><strong>Total Deficit Hours:</strong> <?= $total_deficit_hm ?> hrs</p>
                </div>
            <?php endif; ?>

            <?php sas_upcoming_holidays(10); ?>
        </div>



        <div class="container-mt-4">
            <div class="row">
                <?php sas_motivation_and_insights(); ?>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}


// Helper functions to format hours
function format_hours_minutes($start_time, $end_time, $break_start, $break_end)
{
    if (!$start_time)
        return '00:00';

    $start = strtotime($start_time);
    $end = $end_time ? strtotime($end_time) : current_time('timestamp');

    // Calculate break seconds
    $break_seconds = 0;
    if ($break_start && $break_end) {
        $break_seconds = strtotime($break_end) - strtotime($break_start);
    } elseif ($break_start && !$break_end) {
        $break_seconds = current_time('timestamp') - strtotime($break_start);
    }

    // Worked seconds
    $worked_seconds = $end - $start - $break_seconds;
    if ($worked_seconds < 0)
        $worked_seconds = 0;

    // Convert to hours and minutes
    $hours = floor($worked_seconds / 3600);
    $minutes = floor(($worked_seconds % 3600) / 60);

    return str_pad($hours, 2, '0', STR_PAD_LEFT) . ':' . str_pad($minutes, 2, '0', STR_PAD_LEFT);
}

function format_break_hours($break_start, $break_end)
{
    if (!$break_start)
        return '00:00';

    $start = strtotime($break_start);
    $end = $break_end ? strtotime($break_end) : current_time('timestamp');
    $seconds = $end - $start;
    if ($seconds < 0)
        $seconds = 0;

    $hours = floor($seconds / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    return str_pad($hours, 2, '0', STR_PAD_LEFT) . ':' . str_pad($minutes, 2, '0', STR_PAD_LEFT);
}

add_action('wp_ajax_sas_update_attendance', 'sas_update_attendance');
function sas_update_attendance()
{
    check_ajax_referer('sas_nonce', 'nonce');
    if (!is_user_logged_in())
        wp_send_json_error('Login required.');

    $action = sanitize_text_field($_POST['action_type']);
    $user_id = get_current_user_id();
    $today = date('Y-m-d', current_time('timestamp'));
    global $wpdb;
    $table = $wpdb->prefix . 'attendance_logs';

    $log = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE user_id=%d AND date=%s", $user_id, $today));
    $now = date('Y-m-d H:i:s', current_time('timestamp'));

    if (!$log) {
        $wpdb->insert($table, ['user_id' => $user_id, 'date' => $today]);
        $log_id = $wpdb->insert_id;
        $log = $wpdb->get_row("SELECT * FROM $table WHERE id=$log_id");
    }

    switch ($action) {
        case 'start_day':
            $wpdb->update($table, ['start_time' => $now], ['id' => $log->id]);
            break;
        case 'start_break':
            $wpdb->update($table, ['break_start_time' => $now], ['id' => $log->id]);
            break;
        case 'end_break':
            $break_seconds = 0;
            if ($log->break_start_time) {
                $break_seconds = strtotime($now) - strtotime($log->break_start_time);
            }
            $break_hours = round($break_seconds / 3600, 2);
            $wpdb->update($table, ['break_end_time' => $now, 'break_hours' => $break_hours], ['id' => $log->id]);
            break;
        case 'end_day':
            $work_seconds = 0;
            if ($log->start_time) {
                $start = strtotime($log->start_time);
                $end = strtotime($now);
                $break = $log->break_hours ? $log->break_hours * 3600 : 0;
                $work_seconds = $end - $start - $break;
            }
            $work_hours = round($work_seconds / 3600, 2);
            $wpdb->update($table, ['end_time' => $now, 'work_hours' => $work_hours], ['id' => $log->id]);
            break;
        default:
            wp_send_json_error('Invalid action.');
    }

    wp_send_json_success('Updated');
}

// AJAX to get today's data for real-time update
add_action('wp_ajax_sas_get_today_data', 'sas_get_today_data');
function sas_get_today_data()
{
    check_ajax_referer('sas_nonce', 'nonce');
    if (!is_user_logged_in())
        wp_send_json_error('Login required.');

    $user_id = get_current_user_id();
    $today = date('Y-m-d', current_time('timestamp'));
    global $wpdb;
    $table = $wpdb->prefix . 'attendance_logs';

    $log = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE user_id=%d AND date=%s", $user_id, $today));

    if (!$log)
        wp_send_json_success([
            'start_time' => '',
            'break_start_time' => '',
            'break_end_time' => '',
            'end_time' => '',
            'work_hours' => '00:00',
            'break_hours' => '00:00'
        ]);

    wp_send_json_success([
        'start_time' => $log->start_time ? date('h:i A', strtotime($log->start_time)) : '',
        'break_start_time' => $log->break_start_time ? date('h:i A', strtotime($log->break_start_time)) : '',
        'break_end_time' => $log->break_end_time ? date('h:i A', strtotime($log->break_end_time)) : '',
        'end_time' => $log->end_time ? date('h:i A', strtotime($log->end_time)) : '',
        'work_hours' => format_hours_minutes($log->start_time, $log->end_time, $log->break_start_time, $log->break_end_time),
        'break_hours' => format_break_hours($log->break_start_time, $log->break_end_time)
    ]);
}

// weekly summary 
// Add this inside your attendance dashboard shortcode or a separate function

function sas_weekly_summary()
{
    if (!is_user_logged_in())
        return;

    $user_id = get_current_user_id();
    global $wpdb;
    $table = $wpdb->prefix . 'attendance_logs';

    // Get current week (Mon-Sun)
    $today = current_time('Y-m-d');
    $monday = date('Y-m-d', strtotime('monday this week', strtotime($today)));
    $sunday = date('Y-m-d', strtotime('sunday this week', strtotime($today)));

    // Fetch logs for this week
    $logs = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table WHERE user_id=%d AND date BETWEEN %s AND %s",
        $user_id,
        $monday,
        $sunday
    ));

    $total_seconds = 0;
    $required_daily_hours = 8.5; // could be made configurable later

    foreach ($logs as $log) {
        $start = $log->start_time;
        $end = $log->end_time;
        $break_start = $log->break_start_time;
        $break_end = $log->break_end_time;

        if ($start) {
            // If still working, take "now" as end time
            $end_time = $end ? $end : current_time('H:i:s');
            $worked_seconds = strtotime($end_time) - strtotime($start);

            // Handle break (subtract even if it's ongoing)
            if ($break_start) {
                $break_end_time = $break_end ? $break_end : current_time('H:i:s');
                $break_seconds = strtotime($break_end_time) - strtotime($break_start);
                if ($break_seconds > 0) {
                    $worked_seconds -= $break_seconds;
                }
            }

            if ($worked_seconds > 0) {
                $total_seconds += $worked_seconds;
            }
        }
    }

    // Format total worked time
    $total_hours = floor($total_seconds / 3600);
    $total_minutes = floor(($total_seconds % 3600) / 60);
    $total_worked = sprintf('%02d:%02d', $total_hours, $total_minutes);

    // Weekly requirement (Mon–Fri, 8.5h/day)
    $required_seconds = $required_daily_hours * 3600 * 5;
    $diff_seconds = $total_seconds - $required_seconds;

    if ($diff_seconds >= 0) {
        $status = "Extra";
        $color = "#4caf50";
        $diff_hours = floor($diff_seconds / 3600);
        $diff_minutes = floor(($diff_seconds % 3600) / 60);
        $message = "Great job! You’re ahead by {$diff_hours}h {$diff_minutes}m this week!";
    } else {
        $status = "Deficit";
        $color = "#f44336";
        $diff_seconds = abs($diff_seconds);
        $diff_hours = floor($diff_seconds / 3600);
        $diff_minutes = floor(($diff_seconds % 3600) / 60);
        $message = "Keep going! You still have {$diff_hours}h {$diff_minutes}m to reach weekly target.";
    }

    // Display the card
    echo '<div class="sas-weekly-summary">
            <h3>Weekly Summary</h3>
            <p><strong>Total Worked Hours:</strong> ' . $total_worked . '</p>
            <p><strong>Status:</strong> <span style="color:' . $color . '">' . $status . '</span></p>
            <p>' . $message . '</p>
          </div>';
}


//Leave Management

// Shortcode for Leave Form
add_shortcode('sas_leave_form', 'sas_leave_form_shortcode');

function sas_leave_form_shortcode()
{
    ob_start(); ?>

    <div class="sas-leave-form">
        <h3>Apply for Leave</h3>
        <form id="sas-leave-request-form">
            <label for="leave-date">Select Date:</label>
            <input type="date" id="leave-date" name="leave_date" required>

            <label for="leave-type">Leave Type:</label>
            <select id="leave-type" name="leave_type" required>
                <option value="full_day">Full Day</option>
                <option value="half_day">Half Day</option>
            </select>

            <label for="leave-reason">Reason (optional):</label>
            <textarea id="leave-reason" name="reason" rows="3"></textarea>

            <button type="submit" id="sas-leave-submit">Submit Leave Request</button>
        </form>
        <div id="sas-leave-response"></div>
    </div>

    <?php
    return ob_get_clean();
}


//ajax handler 
// AJAX handler for leave request
add_action('wp_ajax_sas_submit_leave', 'sas_submit_leave');
add_action('wp_ajax_nopriv_sas_submit_leave', 'sas_submit_leave');

function sas_submit_leave()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'attendance_leaves';

    $user_id = get_current_user_id();
    $leave_date = sanitize_text_field($_POST['leave_date']);
    $leave_type = sanitize_text_field($_POST['leave_type']);
    $reason = sanitize_textarea_field($_POST['reason']);

    // Assign hours based on leave type
    $leave_hours = 0;
    if ($leave_type === 'full_day') {
        $leave_hours = 8.5;
    } elseif ($leave_type === 'half_day') {
        $leave_hours = 4.0;
    }

    // Insert into DB
    $wpdb->insert($table_name, [
        'user_id' => $user_id,
        'leave_date' => $leave_date,
        'leave_type' => $leave_type,
        'leave_hours' => $leave_hours,
        'reason' => $reason,
        'status' => 'pending'
    ]);

    wp_send_json_success([
        'message' => 'Leave request submitted successfully!',
        'leave_hours' => $leave_hours
    ]);
}


// Shortcode: [sas_my_leaves]
add_shortcode('sas_my_leaves', 'sas_my_leaves_shortcode');

function sas_my_leaves_shortcode()
{
    if (!is_user_logged_in()) {
        return '<p>You need to log in to view your leave requests.</p>';
    }

    global $wpdb;
    $user_id = get_current_user_id();
    $leave_table = $wpdb->prefix . 'attendance_leaves';

    $results = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM $leave_table WHERE user_id = %d ORDER BY created_at DESC", $user_id)
    );

    ob_start();
    echo '<div class="sas-leaves-wrapper">';
    echo '<h3>My Leave Requests</h3>';
    echo '<table class="sas-leaves-table">';
    echo '<thead><tr>
            <th>Date</th>
            <th>Type</th>
            <th>Hours</th>
            <th>Reason</th>
            <th>Status</th>
          </tr></thead><tbody>';

    if ($results) {
        foreach ($results as $row) {
            echo '<tr>';
            echo '<td>' . esc_html($row->leave_date) . '</td>';
            echo '<td>' . esc_html(ucfirst(str_replace("_", " ", $row->leave_type))) . '</td>';
            echo '<td>' . esc_html($row->leave_hours) . '</td>';
            echo '<td>' . esc_html($row->reason) . '</td>';
            echo '<td><strong>' . ucfirst($row->status) . '</strong></td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="5">No leave requests found.</td></tr>';
    }

    echo '</tbody></table>';
    echo '</div>';

    return ob_get_clean();
}


//get tomorrow leave or not 
function sas_get_tomorrow_leave($user_id = null)
{
    if (!$user_id) {
        if (!is_user_logged_in())
            return false;
        $user_id = get_current_user_id();
    }

    global $wpdb;
    $leaves_table = $wpdb->prefix . 'attendance_leaves';
    $tomorrow = date('Y-m-d', strtotime('+1 day', current_time('timestamp')));

    $leave = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $leaves_table WHERE user_id = %d AND leave_date = %s AND status = 'approved'",
        $user_id,
        $tomorrow
    ), ARRAY_A);

    return $leave ? $leave : false;
}

//daily task module feature
// Shortcode to display daily task logger
add_shortcode('daily_task_logger', 'sas_daily_task_logger');

function sas_daily_task_logger()
{
    if (!is_user_logged_in()) {
        return '<p>Please login to log your tasks.</p>';
    }

    $user_id = get_current_user_id();
    global $wpdb;
    $table = $wpdb->prefix . 'daily_tasks';
    $message = '';

    // Handle form submission (multiple tasks)
    if (isset($_POST['sas_task_submit'])) {
        $project_names = $_POST['project_name'];
        $task_descriptions = $_POST['task_description'];
        $task_statuses = $_POST['task_status'];
        $task_date = date('Y-m-d', current_time('timestamp'));

        foreach ($project_names as $index => $project_name) {
            $proj = sanitize_text_field($project_name);
            $desc = sanitize_textarea_field($task_descriptions[$index]);
            $status = sanitize_text_field($task_statuses[$index]);

            if ($proj && $desc && $status) {
                $wpdb->insert(
                    $table,
                    [
                        'user_id' => $user_id,
                        'project_name' => $proj,
                        'task_description' => $desc,
                        'task_status' => $status,
                        'task_date' => $task_date,
                    ],
                    ['%d', '%s', '%s', '%s', '%s']
                );
            }
        }
        $message = '<p style="color:green;">All tasks logged successfully!</p>';
    }

    // Fetch today's tasks
    $tasks = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table WHERE user_id=%d AND task_date=%s ORDER BY created_at DESC",
        $user_id,
        date('Y-m-d', current_time('timestamp'))
    ));

    ob_start();
    ?>
    <div class="sas-daily-task-logger">
        <h3>Daily Task Logger</h3>
        <?= $message ?>

        <!-- Task Form -->
        <form method="post" id="sas-multi-task-form">
            <div id="sas-task-rows">
                <div class="sas-task-row" style="margin-bottom:10px;">
                    <input type="text" name="project_name[]" placeholder="Project Name" required
                        style="width:30%; padding:8px; margin-right:5px;">
                    <input type="text" name="task_description[]" placeholder="Task Description" required
                        style="width:50%; padding:8px; margin-right:5px;">
                    <select name="task_status[]" required style="width:15%; padding:8px; margin-right:5px;">
                        <option value="done">Done</option>
                        <option value="continue">Continue</option>
                        <option value="pending">Pending</option>
                    </select>
                    <button type="button" class="sas-remove-row" style="padding:5px;">✖</button>
                </div>
            </div>
            <p>
                <button type="button" id="sas-add-row" style="padding:8px 12px; margin-top:5px;">+ Add Another Task</button>
            </p>
            <p>
                <button type="submit" name="sas_task_submit" style="padding:10px 20px;">Log All Tasks</button>
            </p>
        </form>

        <!-- Display Today's Tasks -->
        <div class="day-task">
            <div class="day-task-header">
                <h4>Today's Tasks</h4>
                <button id="sas-copy-tasks"
                    style="padding:8px 15px; margin-bottom:10px; background:#1976d2; color:#fff; border:none; border-radius:6px; cursor:pointer;">
                    Copy Today's Tasks
                </button>

            </div>
            <?php if ($tasks): ?>
                <ul>
                    <?php foreach ($tasks as $task): ?>
                        <li>
                            <strong><?= esc_html($task->project_name) ?></strong> -
                            <?= esc_html($task->task_description) ?>
                            <span
                                style="color:<?= $task->task_status == 'done' ? 'green' : ($task->task_status == 'continue' ? 'orange' : 'red') ?>;">
                                <?= ucfirst($task->task_status) ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>No tasks logged today.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
//historical task

add_shortcode('historical_tasks', 'sas_historical_tasks');

function sas_historical_tasks()
{
    if (!is_user_logged_in()) {
        return '<p>Please login to view historical tasks.</p>';
    }

    $user_id = get_current_user_id();
    global $wpdb;
    $table = $wpdb->prefix . 'daily_tasks';

    // Fetch all tasks for this user, ordered by date descending
    $tasks = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table WHERE user_id=%d ORDER BY task_date DESC, created_at DESC",
        $user_id
    ));

    if (!$tasks) {
        return '<p>No historical tasks found.</p>';
    }

    // Group tasks by date
    $grouped_tasks = [];
    foreach ($tasks as $task) {
        $grouped_tasks[$task->task_date][] = $task;
    }

    ob_start();
    ?>
    <div class="sas-historical-tasks">
        <?php foreach ($grouped_tasks as $date => $tasks_for_date): ?>
            <div class="sas-task-date-group" style="margin-bottom:20px;">
                <h4 style="margin-bottom:10px; color:#1976d2;">
                    <?= date('F j, Y', strtotime($date)) ?>
                </h4>
                <ul style="list-style:none; padding-left:0;">
                    <?php foreach ($tasks_for_date as $task): ?>
                        <li
                            style="padding:8px 12px; margin-bottom:6px; background:#f9f9f9; border-radius:6px; display:flex; justify-content:space-between; align-items:center;">
                            <span>
                                <strong><?= esc_html($task->project_name) ?></strong> – <?= esc_html($task->task_description) ?>
                            </span>
                            <span
                                style="font-weight:600; color:<?= $task->task_status == 'done' ? 'green' : ($task->task_status == 'continue' ? 'orange' : 'red') ?>;">
                                (<?= ucfirst($task->task_status) ?>)
                            </span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endforeach; ?>
    </div>
    <?php

    return ob_get_clean();
}


//UserProfile 

// Shortcode for Enhanced Employee Profile
add_shortcode('employee_profile', 'sas_employee_profile');

function sas_employee_profile()
{
    if (!is_user_logged_in()) {
        return '<p class="sas-login-message">Please login to view your profile.</p>';
    }

    $user_id = get_current_user_id();
    global $wpdb;

    $tasks_table = $wpdb->prefix . 'daily_tasks';

    $message = '';

    // Handle profile update
    if (isset($_POST['sas_profile_submit'])) {
        $first_name = sanitize_text_field($_POST['first_name']);
        $last_name = sanitize_text_field($_POST['last_name']);
        $contact = sanitize_text_field($_POST['contact']);
        $department = sanitize_text_field($_POST['department']);
        $skills = array_map('sanitize_text_field', explode(',', $_POST['skills']));

        // Handle profile picture upload
        if (isset($_FILES['profile_picture']) && !empty($_FILES['profile_picture']['name'])) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            $upload_overrides = ['test_form' => false];
            $uploaded_file = wp_handle_upload($_FILES['profile_picture'], $upload_overrides);

            if (isset($uploaded_file['url'])) {
                update_user_meta($user_id, 'profile_picture', esc_url($uploaded_file['url']));
            } else {
                $message = '<p class="sas-error-message">Failed to upload image.</p>';
            }
        }

        // Update user meta
        update_user_meta($user_id, 'first_name', $first_name);
        update_user_meta($user_id, 'last_name', $last_name);
        update_user_meta($user_id, 'contact', $contact);
        update_user_meta($user_id, 'department', $department);
        update_user_meta($user_id, 'skills', $skills);

        $message = '<p class="sas-success-message">Profile updated successfully!</p>';
    }

    // Fetch user data
    $first_name = get_user_meta($user_id, 'first_name', true);
    $last_name = get_user_meta($user_id, 'last_name', true);
    $contact = get_user_meta($user_id, 'contact', true);
    $department = get_user_meta($user_id, 'department', true);
    $skills = get_user_meta($user_id, 'skills', true) ?: [];
    $profile_picture = get_user_meta($user_id, 'profile_picture', true);

    // Attendance summary
    $month_start = date('Y-m-01', current_time('timestamp'));
    $month_end = date('Y-m-t', current_time('timestamp'));
    $worked_hours = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(TIME_TO_SEC(TIMEDIFF(end_time,start_time)) - IFNULL(TIME_TO_SEC(TIMEDIFF(break_end_time,break_start_time)),0)) 
         FROM {$wpdb->prefix}attendance_logs 
         WHERE user_id=%d AND date BETWEEN %s AND %s",
        $user_id,
        $month_start,
        $month_end
    ));
    $worked_hours_h = floor($worked_hours / 3600);
    $worked_hours_m = floor(($worked_hours % 3600) / 60);
    $worked_hours_hm = sprintf('%02d:%02d', $worked_hours_h, $worked_hours_m);

    // Task summary (only done tasks)
    $tasks_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $tasks_table 
         WHERE user_id=%d AND task_date BETWEEN %s AND %s AND task_status = %s",
        $user_id,
        $month_start,
        $month_end,
        'done'
    ));

    ob_start();
    ?>
    <div class="sas-employee-profile-wrapper">
        <h2 class="sas-profile-heading">My Profile</h2>
        <?= $message ?>

        <form method="post" enctype="multipart/form-data" class="sas-profile-form">
            <div class="sas-profile-picture-wrapper">
                <?php if ($profile_picture): ?>
                    <img src="<?= esc_url($profile_picture) ?>" alt="Profile Picture" class="sas-profile-picture">
                <?php else: ?>
                    <div class="sas-no-picture">No Image</div>
                <?php endif; ?>
                <label class="sas-upload-label">Upload Profile Picture:</label>
                <input type="file" name="profile_picture" accept="image/*" class="sas-upload-input">
            </div>

            <div class="sas-name-fields">
                <input type="text" name="first_name" value="<?= esc_attr($first_name) ?>" placeholder="First Name" required
                    class="sas-first-name">
                <input type="text" name="last_name" value="<?= esc_attr($last_name) ?>" placeholder="Last Name" required
                    class="sas-last-name">
            </div>

            <p class="sas-contact-field">
                <label>Contact Number:</label>
                <input type="text" name="contact" value="<?= esc_attr($contact) ?>" class="sas-contact-input">
            </p>

            <p class="sas-department-field">
                <label>Department:</label>
                <input type="text" name="department" value="<?= esc_attr($department) ?>" class="sas-department-input">
            </p>

            <p class="sas-skills-field">
                <label>Skills (comma separated):</label>
                <input type="text" name="skills" value="<?= implode(',', array_map('esc_attr', $skills)) ?>"
                    class="sas-skills-input">
            </p>

            <p class="sas-submit-field">
                <button type="submit" name="sas_profile_submit" class="sas-update-btn">Update Profile</button>
            </p>
        </form>

        <div class="sas-profile-summary">
            <div class="sas-summary-box">
                <h4>Attendance (This Month)</h4>
                <p class="sas-summary-value"><?= $worked_hours_hm ?> hrs</p>
            </div>
            <div class="sas-summary-box">
                <h4>Tasks Completed</h4>
                <p class="sas-summary-value"><?= $tasks_count ?></p>
            </div>
            <div class="sas-summary-box">
                <h4>Skills</h4>
                <p class="sas-summary-value"><?= $skills ? implode(', ', array_map('esc_html', $skills)) : 'None' ?></p>
            </div>
            <div class="sas-summary-box">
                <h4>Department</h4>
                <p class="sas-summary-value"><?= $department ? esc_html($department) : 'Not Set' ?></p>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

function sas_daily_breakdown()
{
    if (!is_user_logged_in())
        return;

    $user_id = get_current_user_id();
    global $wpdb;
    $table = $wpdb->prefix . 'attendance_logs';

    // Get current week (Mon–Fri)
    $today = current_time('Y-m-d');
    $monday = date('Y-m-d', strtotime('monday this week', strtotime($today)));
    $friday = date('Y-m-d', strtotime('friday this week', strtotime($today)));

    // Fetch logs for this week grouped by day
    $logs = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table WHERE user_id=%d AND date BETWEEN %s AND %s ORDER BY date ASC",
        $user_id,
        $monday,
        $friday
    ));

    // Organize logs by date
    $daily_data = [];
    foreach ($logs as $log) {
        $date = $log->date;
        if (!isset($daily_data[$date])) {
            $daily_data[$date] = 0;
        }

        $start = $log->start_time;
        $end = $log->end_time;
        $break_start = $log->break_start_time;
        $break_end = $log->break_end_time;

        if ($start) {
            // If still working, use now as end
            $end_time = $end ? $end : current_time('H:i:s');
            $worked_seconds = strtotime($end_time) - strtotime($start);

            // Handle breaks
            if ($break_start) {
                $break_end_time = $break_end ? $break_end : current_time('H:i:s');
                $break_seconds = strtotime($break_end_time) - strtotime($break_start);
                if ($break_seconds > 0) {
                    $worked_seconds -= $break_seconds;
                }
            }

            if ($worked_seconds > 0) {
                $daily_data[$date] += $worked_seconds;
            }
        }
    }

    // Render Table
    echo '<div class="sas-daily-breakdown">';
    echo '<h3>Daily Breakdown (Mon–Fri)</h3>';
    echo '<table class="sas-daily-table">';
    echo '<tr><th>Day</th><th>Worked</th><th>Status</th></tr>';

    $required_seconds = 8.5 * 3600;

    for ($i = 0; $i < 7; $i++) {
        $day_date = date('Y-m-d', strtotime("+$i day", strtotime($monday)));
        $day_name = date('D', strtotime($day_date));
        $day_number = date('N', strtotime($day_date)); // 1=Mon, 7=Sun

        if ($day_number >= 6) {
            // Sat & Sun -> Holiday
            echo "<tr>
                    <td>{$day_name}</td>
                    <td>-</td>
                    <td>🟢 Holiday</td>
                  </tr>";
            continue;
        }

        $worked_seconds = isset($daily_data[$day_date]) ? $daily_data[$day_date] : 0;
        $hours = floor($worked_seconds / 3600);
        $minutes = floor(($worked_seconds % 3600) / 60);
        $worked = ($worked_seconds > 0) ? "{$hours}h {$minutes}m" : "-";

        $today_date = current_time('Y-m-d');

        if ($day_date > $today_date) {
            // Future day
            $status = "⏳ Upcoming";
        } elseif ($day_date == $today_date) {
            // Today
            if ($worked_seconds > 0) {
                $status = ($worked_seconds >= $required_seconds) ? "✅ Met" : "⚠️ Short (so far)";
            } else {
                $status = "⌛ Not started";
            }
        } else {
            // Past days
            if ($worked_seconds >= $required_seconds) {
                $status = "✅ Met";
            } elseif ($worked_seconds > 0) {
                $status = "⚠️ Short";
            } else {
                $status = "❌ Absent";
            }
        }

        echo "<tr>
                <td>{$day_name}</td>
                <td>{$worked}</td>
                <td>{$status}</td>
              </tr>";
    }

    echo '</table>';
    echo '</div>';
}


function sas_motivation_and_insights()
{
    if (!is_user_logged_in())
        return;

    $user_id = get_current_user_id();
    global $wpdb;
    $table = $wpdb->prefix . 'attendance_logs';

    $today = current_time('Y-m-d');
    $monday = date('Y-m-d', strtotime('monday this week', strtotime($today)));
    $friday = date('Y-m-d', strtotime('friday this week', strtotime($today)));
    $start_date = date('Y-m-d', strtotime('-30 days', strtotime($today)));

    $logs = $wpdb->get_results($wpdb->prepare(
        "SELECT date, start_time, end_time, break_start_time, break_end_time 
         FROM $table 
         WHERE user_id=%d AND date BETWEEN %s AND %s 
         ORDER BY date ASC",
        $user_id,
        $start_date,
        $today
    ));

    $required_seconds = 8.5 * 3600;
    $daily_data = [];
    $longest_day = 0;
    $longest_day_label = '';
    $total_seconds = 0;
    $days_count = 0;

    // Streaks
    $best_streak = 0;
    $current_streak = 0;

    foreach ($logs as $log) {
        $worked_seconds = 0;

        if ($log->start_time) {
            $end = $log->end_time ? $log->end_time : current_time('H:i:s');
            $worked_seconds = strtotime($end) - strtotime($log->start_time);

            if ($log->break_start_time) {
                $break_end = $log->break_end_time ? $log->break_end_time : current_time('H:i:s');
                $worked_seconds -= (strtotime($break_end) - strtotime($log->break_start_time));
            }
        }

        if ($worked_seconds > 0) {
            $day_name = date('D', strtotime($log->date));
            $daily_data[$log->date] = $worked_seconds;
            $total_seconds += $worked_seconds;
            $days_count++;

            if ($worked_seconds > $longest_day) {
                $longest_day = $worked_seconds;
                $longest_day_label = "{$day_name}";
            }
        }
    }

    // Calculate best streak (Mon–Fri only)
    $streak = 0;
    for ($i = 0; $i < 30; $i++) {
        $day_date = date('Y-m-d', strtotime("-$i day", strtotime($today)));
        $day_number = date('N', strtotime($day_date)); // 1=Mon,7=Sun
        if ($day_number >= 6)
            continue; // Skip Sat/Sun

        $worked = isset($daily_data[$day_date]) ? $daily_data[$day_date] : 0;

        if ($worked >= $required_seconds) {
            $streak++;
            if ($streak > $best_streak)
                $best_streak = $streak;
        } else {
            $streak = 0;
        }
    }

    // Average hours
    $avg_seconds = ($days_count > 0) ? $total_seconds / $days_count : 0;
    $avg_hours = floor($avg_seconds / 3600);
    $avg_minutes = floor(($avg_seconds % 3600) / 60);

    // Longest day
    $longest_hours = floor($longest_day / 3600);
    $longest_minutes = floor(($longest_day % 3600) / 60);

    // Streak message
    $streak_message = $best_streak > 0
        ? "🔥 Best streak: {$best_streak} days in a row!"
        : "⏳ No streak yet — aim for consistent hours!";

    // Render Section
    echo '<div class="sas-motivation-insights">';
    echo '<h3>✨ Motivation & Insights</h3>';

    // Streak Tracker
    echo '<div class="sas-streak">';
    echo "<p><strong>Streak Tracker:</strong> {$streak_message}</p>";
    echo '</div>';

    // Highlights
    echo '<div class="sas-highlights">';
    echo '<ul>';
    echo "<li>🏆 Longest day: {$longest_hours}h {$longest_minutes}m ({$longest_day_label})</li>";
    echo "<li>📊 Average daily hours: {$avg_hours}h {$avg_minutes}m</li>";
    echo "<li>🔥 Weekly best streak: {$best_streak} days in a row</li>";
    echo '</ul>';
    echo '</div>';

    echo '</div>';
}
function sas_upcoming_holidays($limit = 15)
{
    if (!is_user_logged_in()) {
        return;
    }

    global $wpdb;
    $table = $wpdb->prefix . 'sas_holidays';
    $today = current_time('Y-m-d');

    $holidays = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table WHERE date >= %s ORDER BY date ASC LIMIT %d",
        $today,
        $limit
    ));

    echo '<div class="sas-holiday-card">';
    echo '<h3>Upcoming Holidays 🎉</h3>';
    echo '<ul>';

    if ($holidays) {
        foreach ($holidays as $h) {
            echo "<li>" . esc_html($h->date) . " - " . esc_html($h->name) . "</li>";
        }
    } else {
        echo '<li>No upcoming holidays 🎊</li>';
    }

    echo '</ul>';
    echo '</div>';
}


//total leave calanedr
// Shortcode: [sas_leave_calendar]
function sas_leave_calendar_shortcode($atts)
{
    global $wpdb;
    $table = $wpdb->prefix . 'sas_holidays';

    // Fetch all holidays
    $holidays = $wpdb->get_results("SELECT * FROM $table ORDER BY date ASC");

    ob_start();
    echo '<div class="sas-leave-calendar">';
    echo '<h3>Leave / Holiday Calendar 📅</h3>';
    echo '<table class="sas-leave-table">';
    echo '<tr><th>Date</th><th>Holiday</th></tr>';

    if ($holidays) {
        foreach ($holidays as $h) {
            echo "<tr>
                    <td>" . esc_html(date('d M Y', strtotime($h->date))) . "</td>
                    <td>" . esc_html($h->name) . "</td>
                  </tr>";
        }
    } else {
        echo '<tr><td colspan="2">No holidays found</td></tr>';
    }

    echo '</table>';
    echo '</div>';
    return ob_get_clean();
}
add_shortcode('sas_leave_calendar', 'sas_leave_calendar_shortcode');

