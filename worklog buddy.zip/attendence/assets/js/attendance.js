jQuery(document).ready(function () {

    // Button click handler
    jQuery('.sas-btn').click(function () {
        var action_type = jQuery(this).data('action');
        jQuery.post(sas_ajax.ajax_url, {
            action: 'sas_update_attendance',
            nonce: sas_ajax.nonce,
            action_type: action_type
        }, function (res) {
            if (res.success) updateDashboard();
            else alert(res.data);
        });
    });

    // Function to fetch latest attendance data via AJAX
    function updateDashboard() {
        jQuery.post(sas_ajax.ajax_url, {
            action: 'sas_get_today_data',
            nonce: sas_ajax.nonce
        }, function (res) {
            if (res.success) {
                var data = res.data;

                jQuery('#sas-start').text(data.start_time || '-');
                jQuery('#sas-break-start').text(data.break_start_time || '-');
                jQuery('#sas-break-end').text(data.break_end_time || '-');
                jQuery('#sas-end').text(data.end_time || '-');
                jQuery('#sas-work').text(data.work_hours);
                jQuery('#sas-break-hours').text(data.break_hours);
                var status = '-';
                var status_class = '';

                if (!data.start_time) {
                    status = 'Not Started';
                    status_class = 'sas-status-notstarted';
                } else if (data.start_time && !data.break_start_time) {
                    status = 'Working';
                    status_class = 'sas-status-working';
                } else if (data.break_start_time && !data.break_end_time) {
                    status = 'On Break';
                    status_class = 'sas-status-break';
                } else if (data.end_time) {
                    status = 'Day Ended';
                    status_class = 'sas-status-ended';
                } else {
                    status = 'Working';
                    status_class = 'sas-status-working';
                }

                // Update status label text and class
                var $status = jQuery('#sas-status');
                $status.text('Status: ' + status);
                $status.removeClass('sas-status-working sas-status-break sas-status-ended sas-status-notstarted');
                $status.addClass(status_class);



                // Button logic
                jQuery('.sas-btn').prop('disabled', false); // enable all initially

                if (!data.start_time) {
                    // Day not started
                    jQuery('[data-action="start_day"]').prop('disabled', false);
                    jQuery('[data-action="start_break"], [data-action="end_break"], [data-action="end_day"]').prop('disabled', true);
                } else if (data.start_time && !data.break_start_time) {
                    // Day started, no break
                    jQuery('[data-action="start_break"], [data-action="end_day"]').prop('disabled', false);
                    jQuery('[data-action="start_day"], [data-action="end_break"]').prop('disabled', true);
                } else if (data.break_start_time && !data.break_end_time) {
                    // On break
                    jQuery('[data-action="end_break"]').prop('disabled', false);
                    jQuery('[data-action="start_day"], [data-action="start_break"], [data-action="end_day"]').prop('disabled', true);
                } else if (data.end_time) {
                    // Day ended
                    jQuery('.sas-btn').prop('disabled', true);
                } else {
                    // After break ended but day not ended
                    jQuery('[data-action="end_day"]').prop('disabled', false);
                    jQuery('[data-action="start_day"], [data-action="start_break"], [data-action="end_break"]').prop('disabled', true);
                }
            }
        });
    }

    // Initial load
    updateDashboard();

    // Real-time update every 1 second
    setInterval(updateDashboard, 1000);
});


//leave Management

jQuery(document).ready(function () {
    jQuery("#sas-leave-request-form").on("submit", function (e) {
        e.preventDefault();

        var formData = {
            action: "sas_submit_leave",
            leave_date: jQuery("#leave-date").val(),
            leave_type: jQuery("#leave-type").val(),
            reason: jQuery("#leave-reason").val()
        };

        jQuery.post(sas_ajax.ajax_url, formData, function (response) {
            if (response.success) {
                jQuery("#sas-leave-response").html("<p style='color:green'>" + response.data.message + "</p>");
                jQuery("#sas-leave-request-form")[0].reset();
            } else {
                jQuery("#sas-leave-response").html("<p style='color:red'>Error submitting leave.</p>");
            }
        });
    });
});


//task script
document.addEventListener("DOMContentLoaded", function () {
    const addRowBtn = document.getElementById('sas-add-row');
    const taskRows = document.getElementById('sas-task-rows');

    // Add new task row
    addRowBtn.addEventListener('click', function () {
        const firstRow = document.querySelector('.sas-task-row');
        const newRow = firstRow.cloneNode(true);

        // Clear values for inputs and selects
        newRow.querySelectorAll('input').forEach(input => input.value = '');
        newRow.querySelectorAll('select').forEach(select => select.selectedIndex = 0);

        taskRows.appendChild(newRow);
    });

    // Remove task row
    taskRows.addEventListener('click', function (e) {
        if (e.target.classList.contains('sas-remove-row')) {
            const row = e.target.closest('.sas-task-row');
            if (taskRows.children.length > 1) {
                row.remove();
            }
        }
    });
});

//copy today's task

document.addEventListener("DOMContentLoaded", function () {
    const copyBtn = document.getElementById('sas-copy-tasks');

    function showToast(message, bgColor = "#1976d2") {
        const toast = document.createElement('div');
        toast.className = 'sas-toast';
        toast.style.background = bgColor;
        toast.innerText = message;
        document.body.appendChild(toast);

        // Trigger animation
        setTimeout(() => toast.classList.add('show'), 10);

        // Remove after 3 seconds
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    copyBtn.addEventListener('click', function () {
        const taskItems = document.querySelectorAll('.day-task ul li');

        if (taskItems.length === 0) {
            showToast("No tasks to copy today!", "#f44336"); // red
            return;
        }

        let textToCopy = '';
        taskItems.forEach((li, index) => {
            const project = li.querySelector('strong').innerText.trim();
            const statusSpan = li.querySelector('span');
            let description = li.childNodes[2].textContent || '';
            description = description.replace(/\s+/g, ' ').trim(); // remove extra spaces

            let status = statusSpan ? statusSpan.innerText.trim() : '';
            status = status.replace(/\s+/g, ''); // remove spaces in status for tight parentheses

            textToCopy += `${index + 1}. ${project} - ${description}(${status})\n`;
        });

        navigator.clipboard.writeText(textToCopy).then(() => {
            showToast("Today's tasks copied to clipboard!", "#4caf50"); // green
        }).catch(() => {
            showToast("Failed to copy tasks.", "#f44336"); // red
        });
    });
});

jQuery(document).ready(function () {
    function refreshWeeklySummary() {
        jQuery.ajax({
            url: sas_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'sas_get_weekly_summary',
                _ajax_nonce: sas_ajax.nonce
            },
            success: function (response) {
                jQuery('#sas-weekly-summary-container').html(response);
            }
        });
    }

    // Refresh every 60 seconds
    setInterval(refreshWeeklySummary, 60000);

    // Also refresh once on page load (in case it's stale)
    refreshWeeklySummary();
});
