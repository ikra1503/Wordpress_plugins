<?php
/*
Plugin Name: WorkLog Buddy
Description: Friendly, easy to remember, emphasizes daily logging.
Version: 1.0
Author: Ikramul Shekh
*/

if (!defined('ABSPATH'))
    exit;

// Include user and admin parts
include_once plugin_dir_path(__FILE__) . 'user-dashboard.php';
include_once plugin_dir_path(__FILE__) . 'admin-dashboard.php';

// Activation: Create DB table
register_activation_hook(__FILE__, 'sas_create_db_table');
function sas_create_db_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'attendance_logs';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) NOT NULL,
        date DATE NOT NULL,
        start_time DATETIME DEFAULT NULL,
        break_start_time DATETIME DEFAULT NULL,
        break_end_time DATETIME DEFAULT NULL,
        end_time DATETIME DEFAULT NULL,
        work_hours DECIMAL(5,2) DEFAULT 0,
        break_hours DECIMAL(5,2) DEFAULT 0,
        PRIMARY KEY(id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

register_activation_hook(__FILE__, 'sas_create_leave_table');

function sas_create_leave_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'attendance_leaves';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        leave_date DATE NOT NULL,
        leave_type ENUM('full_day','half_day') NOT NULL DEFAULT 'full_day',
        leave_hours FLOAT NOT NULL DEFAULT 0,   /* <--- NEW COLUMN */
        status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
        reason TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

function sas_create_daily_tasks_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'daily_tasks';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        project_name VARCHAR(255) NOT NULL,
        task_description TEXT NOT NULL,
        task_status ENUM('done','continue','pending') DEFAULT 'pending',
        task_date DATE NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
// add_action('after_setup_theme', 'sas_create_daily_tasks_table');
register_activation_hook(__FILE__, 'sas_create_daily_tasks_table');

// Enqueue CSS & JS
add_action('wp_enqueue_scripts', 'sas_enqueue_assets');
function sas_enqueue_assets()
{
    wp_enqueue_style('sas-css', plugin_dir_url(__FILE__) . 'assets/css/attendance.css');
    wp_enqueue_script('sas-js', plugin_dir_url(__FILE__) . 'assets/js/attendance.js', array('jquery'), false, true);
    wp_localize_script('sas-js', 'sas_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('sas_nonce')
    ));
}

// Admin enqueue
add_action('admin_enqueue_scripts', function () {
    wp_enqueue_style('sas-css', plugin_dir_url(__FILE__) . 'assets/css/attendance.css');
});


// Enqueue Bootstrap for plugin
add_action('wp_enqueue_scripts', 'sas_enqueue_bootstrap');
function sas_enqueue_bootstrap()
{
    // Bootstrap CSS
    wp_enqueue_style(
        'sas-bootstrap-css',
        'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css',
        [],
        '5.3.2'
    );

    // Bootstrap JS (optional, if you need modals, dropdowns etc.)
    wp_enqueue_script(
        'sas-bootstrap-js',
        'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js',
        ['jquery'], // dependency
        '5.3.2',
        true // load in footer
    );
}

// Remove page titles for all pages
add_filter('the_title', 'sas_remove_page_title', 10, 2);
function sas_remove_page_title($title, $id)
{
    if (is_page($id) && !is_admin()) {
        return '';
    }
    return $title;
}
// AJAX: return weekly summary HTML
add_action('wp_ajax_sas_get_weekly_summary', 'sas_get_weekly_summary');
add_action('wp_ajax_nopriv_sas_get_weekly_summary', 'sas_get_weekly_summary');

function sas_get_weekly_summary()
{
    ob_start();
    sas_weekly_summary(); // reuse your existing function
    $html = ob_get_clean();
    echo $html;
    wp_die();
}
register_activation_hook(__FILE__, 'sas_create_holiday_table');
// add_action('init', 'sas_create_holiday_table');
function sas_create_holiday_table()
{
    global $wpdb;
    $table = $wpdb->prefix . 'sas_holidays';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        date date NOT NULL,
        name varchar(200) NOT NULL,
        type varchar(20) DEFAULT 'full' NOT NULL, 
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
