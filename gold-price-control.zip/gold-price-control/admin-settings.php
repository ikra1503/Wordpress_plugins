<?php
// Add settings field under WooCommerce > Settings > Products > Metal Pricing
// ----------------------------
// 1️⃣ Add admin menu
// ----------------------------
add_action('admin_menu', 'metal_price_api_menu');
function metal_price_api_menu() {
    add_menu_page(
        'Metal Pricing Settings',   // Page title
        'Metal Pricing',            // Menu title
        'manage_options',           // Capability
        'metal-pricing-settings',   // Menu slug
        'metal_price_api_page',     // Callback function
        'dashicons-admin-generic',  // Icon
        60                          // Position
    );
     add_submenu_page(
        'metal-pricing-settings',      // Parent slug
        'Commission Settings',         // Page title
        'Commission',                  // Menu title
        'manage_options',              // Capability
        'metal-commission-settings',   // Menu slug
        'metal_commission_page'        // Callback function
    );
}

// ----------------------------
// 2️⃣ Render admin page
// ----------------------------
function metal_price_api_page() {
    // Check if user has permission
    if (!current_user_can('manage_options')) return;

    // Save option if form submitted
    if (isset($_POST['metal_price_api_submit'])) {
        check_admin_referer('metal_price_api_nonce');
        $api_url = sanitize_text_field($_POST['live_metal_price_api']);
        update_option('live_metal_price_api', $api_url);
        echo '<div class="notice notice-success is-dismissible"><p>API URL saved successfully!</p></div>';
    }

    // Get saved option
    $saved_api = get_option('live_metal_price_api', '');

    ?>
    <div class="wrap">
        <h1>Metal Pricing Settings</h1>

        <form method="post" action="">
            <?php wp_nonce_field('metal_price_api_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="live_metal_price_api">Live Metal Price API URL</label></th>
                    <td>
                        <input type="text" name="live_metal_price_api" id="live_metal_price_api" value="<?php echo esc_attr($saved_api); ?>" class="regular-text" />
                        <p class="description">Enter your API URL that returns metal prices in JSON format.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save API URL', 'primary', 'metal_price_api_submit'); ?>
        </form>

        <?php if ($saved_api): ?>
            <h2>Test API</h2>
            <form method="post" action="">
                <?php wp_nonce_field('metal_price_api_test_nonce'); ?>
                <input type="hidden" name="test_api" value="1">
                <?php submit_button('Fetch Live Prices'); ?>
            </form>

            <?php
            // Handle API test
            if (isset($_POST['test_api'])) {
                check_admin_referer('metal_price_api_test_nonce');

                $response = wp_remote_get($saved_api);
                if (is_wp_error($response)) {
                    echo '<div class="notice notice-error"><p>Error fetching API: ' . esc_html($response->get_error_message()) . '</p></div>';
                } else {
                    $body = wp_remote_retrieve_body($response);
                    $prices = json_decode($body, true);
                    if ($prices) {
                        echo '<h3>Live Metal Prices:</h3>';
                        echo '<pre>' . esc_html(json_encode($prices, JSON_PRETTY_PRINT)) . '</pre>';
                    } else {
                        echo '<div class="notice notice-warning"><p>API did not return valid JSON.</p></div>';
                    }
                }
            }
            ?>
        <?php endif; ?>
    </div>
    <?php
}

function metal_commission_page() {
    if (!current_user_can('manage_options')) return;

    // Default commissions (example)
    $default_commission = array(
        "gold" => [
            "24k" => 5,
            "22k" => 4,
            "21k" => 3.5,
            "18k" => 3,
        ],
        "silver" => [
            "999" => 2,
            "925" => 1.8,
            "900" => 1.5,
            "800" => 1.2,
        ]
    );

    // Save if form submitted
    if (isset($_POST['metal_commission_submit'])) {
        check_admin_referer('metal_commission_nonce');
        $commissions = array();

        // Loop through gold
        $commissions['gold'] = array();
        foreach (['24k','22k','21k','18k'] as $karat) {
            $commissions['gold'][$karat] = isset($_POST["gold_$karat"]) ? floatval($_POST["gold_$karat"]) : 0;
        }

        // Loop through silver
        $commissions['silver'] = array();
        foreach (['999','925','900','800'] as $purity) {
            $commissions['silver'][$purity] = isset($_POST["silver_$purity"]) ? floatval($_POST["silver_$purity"]) : 0;
        }

        update_option('metal_commissions', $commissions);
        echo '<div class="notice notice-success is-dismissible"><p>Commission rates saved successfully!</p></div>';
    }

    // Get saved or default
    $commissions = get_option('metal_commissions', $default_commission);
    ?>
    <div class="wrap">
        <h1>Commission Settings</h1>
        <form method="post" action="">
            <?php wp_nonce_field('metal_commission_nonce'); ?>
            
            <h2>Gold Commission (%)</h2>
            <table class="form-table">
                <?php foreach ($commissions['gold'] as $karat => $rate): ?>
                    <tr>
                        <th scope="row"><label for="gold_<?php echo $karat; ?>">Gold <?php echo $karat; ?></label></th>
                        <td><input type="number" step="0.1" min="0" name="gold_<?php echo $karat; ?>" value="<?php echo esc_attr($rate); ?>">%</td>
                    </tr>
                <?php endforeach; ?>
            </table>

            <h2>Silver Commission (%)</h2>
            <table class="form-table">
                <?php foreach ($commissions['silver'] as $purity => $rate): ?>
                    <tr>
                        <th scope="row"><label for="silver_<?php echo $purity; ?>">Silver <?php echo $purity; ?></label></th>
                        <td><input type="number" step="0.1" min="0" name="silver_<?php echo $purity; ?>" value="<?php echo esc_attr($rate); ?>">%</td>
                    </tr>
                <?php endforeach; ?>
            </table>

            <?php submit_button('Save Commission Rates', 'primary', 'metal_commission_submit'); ?>
        </form>
    </div>
    <?php
}
//product setting 
add_action('woocommerce_product_options_general_product_data', 'add_metal_custom_fields');
function add_metal_custom_fields() {
    echo '<div class="options_group">';

    // Metal Type
    woocommerce_wp_select(array(
        'id'      => '_metal_type',
        'label'   => __('Metal Type', 'woocommerce'),
        'options' => array(
            ''       => __('Select Metal', 'woocommerce'),
            'gold'   => __('Gold', 'woocommerce'),
            'silver' => __('Silver', 'woocommerce'),
        ),
        'desc_tip'    => true,
        'description' => 'Select the metal type (Gold or Silver).',
    ));

    // Karat / Purity
    woocommerce_wp_select(array(
        'id'      => '_karat',
        'label'   => __('Karat / Purity', 'woocommerce'),
        'options' => array(
            ''      => __('Select Karat/Purity', 'woocommerce'),
            // Gold options
            '24k'   => __('Gold 24K', 'woocommerce'),
            '22k'   => __('Gold 22K', 'woocommerce'),
            '21k'   => __('Gold 21K', 'woocommerce'),
            '18k'   => __('Gold 18K', 'woocommerce'),
            // Silver options
            '999'   => __('Silver 999', 'woocommerce'),
            '925'   => __('Silver 925', 'woocommerce'),
            '900'   => __('Silver 900', 'woocommerce'),
            '800'   => __('Silver 800', 'woocommerce'),
        ),
        'desc_tip'    => true,
        'description' => 'Select Karat for Gold or Purity for Silver.',
    ));

    // Weight in grams
    woocommerce_wp_text_input(array(
        'id'          => '_metal_qty',
        'label'       => __('Weight (grams)', 'woocommerce'),
        'type'        => 'number',
        'custom_attributes' => array(
            'min'  => '1',
            'max'  => '500',
            'step' => '1',
        ),
        'desc_tip'    => true,
        'description' => 'Enter the weight of the metal in grams (1–500).',
    ));

    echo '</div>';
}

// ----------------------
// 3️⃣ SAVE CUSTOM FIELDS
// ----------------------
add_action('woocommerce_process_product_meta', 'save_metal_custom_fields');
function save_metal_custom_fields($post_id) {
    $metal_type = isset($_POST['_metal_type']) ? sanitize_text_field($_POST['_metal_type']) : '';
    $karat      = isset($_POST['_karat']) ? sanitize_text_field($_POST['_karat']) : '';
    $weight     = isset($_POST['_metal_qty']) ? floatval($_POST['_metal_qty']) : '';

    update_post_meta($post_id, '_metal_type', $metal_type);
    update_post_meta($post_id, '_karat', $karat);
    update_post_meta($post_id, '_metal_qty', $weight);
}

?>