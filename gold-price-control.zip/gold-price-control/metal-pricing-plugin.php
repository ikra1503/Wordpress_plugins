<?php
/**
 * Plugin Name: Metal Pricing for WooCommerce
 * Description: Dynamic metal pricing with commissions for WooCommerce products.
 * Version: 1.0
 * Author: Ikram Shekh 
 * Text Domain: metal-pricing
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Include admin settings
include_once(plugin_dir_path(__FILE__) . 'admin-settings.php');

function get_live_metal_prices() {
    $api_url = get_option('live_metal_price_api');

    if (!$api_url) return false;

    // Use transient to cache for 1 hour
    $cached = get_transient('live_metal_prices');
    if ($cached !== false) return $cached;

    $response = wp_remote_get($api_url);
    if (is_wp_error($response)) return false;

    $body = wp_remote_retrieve_body($response);
    $prices = json_decode($body, true);

    if ($prices) {
        set_transient('live_metal_prices', $prices, HOUR_IN_SECONDS);
        return $prices;
    }

    return false;
}

add_filter('woocommerce_product_get_price', 'custom_metal_price_api', 10, 2);
add_filter('woocommerce_product_get_regular_price', 'custom_metal_price_api', 10, 2);
add_filter('woocommerce_product_get_sale_price', 'custom_metal_price_api', 10, 2);

function custom_metal_price_api($price, $product) {

    $metal_type = get_post_meta($product->get_id(), '_metal_type', true);
    $karat      = get_post_meta($product->get_id(), '_karat', true);
    $weight     = get_post_meta($product->get_id(), '_metal_qty', true);

    if (!$metal_type || !$karat || !$weight) return $price;

    // Get live metal prices
    $prices = get_live_metal_prices();
    if (!$prices || !isset($prices[$metal_type][$karat])) return $price;

    $price_per_gram = floatval($prices[$metal_type][$karat]);
    $base_price = $weight * $price_per_gram;

    // Get commission rates
    $commissions = get_option('metal_commissions', []);
    $commission_percent = 0;

    if (isset($commissions[$metal_type][$karat])) {
        $commission_percent = floatval($commissions[$metal_type][$karat]);
    }

    // Apply commission
    $final_price = $base_price + ($base_price * $commission_percent / 100);

    return $final_price;
}
?>