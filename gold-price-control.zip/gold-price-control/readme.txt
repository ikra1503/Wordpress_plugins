=== Gold Price Control API Plugin ===
Contributors: Ikram Shekh
Tags: gold, silver, live pricing, woocommerce, api, commission
Requires at least: 5.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Gold Price Control API Plugin integrates live gold and silver prices directly into your WooCommerce store.
It fetches real-time metal prices from a custom JSON API and applies a commission percentage you control from the admin panel.

This plugin adds pricing logic for products based on selected metal type (Gold or Silver) and purity (e.g., 24K, 22K, 999, 925).

== How It Works ==
1. Install and activate the plugin.
2. A new meta box will appear on WooCommerce product edit screens, allowing you to select:
   - Metal Type: Gold / Silver
   - Purity: e.g., 24K, 22K, 999, etc.
   - Weight: e.g., 10g, 50g, etc.
3. The plugin automatically fetches prices from a JSON API:
   /wp-content/uploads/2025/11/price.json

Example JSON:
{
  "gold": {
    "24k": 60.50,
    "22k": 55.40
  },
  "silver": {
    "999": 0.80,
    "925": 0.75
  }
}

4. The admin settings page lets you:
   - Enter your API URL.
   - Set commission (%) for pricing adjustments.

== Commission Logic ==
Base Price = (Live Rate * Weight)
Final Price = Base Price + (Base Price * Commission%)

It displays both:
- Price Before Commission
- Price After Commission

(for debugging or live comparison).

== Admin Options ==
- API URL field to control which JSON API to fetch metal prices from.
- Commission (%) field to control markup applied to product prices.

== Compatibility ==
- WooCommerce 5.0+
- WordPress 5.0+
- PHP 7.4 – 8.3

== Installation ==
1. Upload gold-price-control-api.zip to /wp-content/plugins/.
2. Activate it via Plugins → Installed Plugins.
3. Go to WooCommerce → Settings → Gold Price Control to configure.

== Debug Example ==
For debugging purposes, the plugin logs both:
Price before commission: $60.50
Price after commission: $63.53

== Changelog ==
= 1.0 =
- Initial release
- Added gold/silver support
- Added commission control
- Added admin settings for API URL
